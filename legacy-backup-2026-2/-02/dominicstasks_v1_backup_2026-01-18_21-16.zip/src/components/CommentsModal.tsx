import React, { useState, useEffect, useRef } from 'react';
import { useTasks } from '../context/TasksContext';
import { useAuth } from '../context/AuthContext';
import { Task } from '../types';
import { X, Send, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';

interface CommentsModalProps {
  task: Task;
  isOpen: boolean;
  onClose: () => void;
}

const CommentsModal: React.FC<CommentsModalProps> = ({ task, isOpen, onClose }) => {
  const { user } = useAuth();
  const { addTaskComment, getTaskComments } = useTasks();
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [sendingComment, setSendingComment] = useState(false);
  const [loading, setLoading] = useState(true);
  const commentsEndRef = useRef<HTMLDivElement>(null);

  // Fetch comments when modal opens
  useEffect(() => {
    if (isOpen && task.id) {
      fetchComments();
    }
  }, [isOpen, task.id]);

  // Scroll to bottom when new comments arrive
  useEffect(() => {
    commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [comments]);

  const fetchComments = async () => {
    try {
      const fetchedComments = await getTaskComments(task.id);
      setComments(fetchedComments);
    } catch (error) {
      console.error('Error fetching comments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !user) return;

    setSendingComment(true);
    try {
      await addTaskComment(task.id, task.title, newComment.trim());
      
      // Refresh comments list
      const fetchedComments = await getTaskComments(task.id);
      setComments(fetchedComments);
      
      setNewComment('');
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setSendingComment(false);
    }
  };

  const formatCommentTime = (date: Date) => {
    return format(date, 'MMM d, h:mm a');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[80vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <MessageCircle className="text-blue-500" size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-gray-800 truncate max-w-[250px]">
                {task.title}
              </h3>
              <p className="text-xs text-gray-500">Comments</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
            </div>
          ) : comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-gray-400">
              <MessageCircle size={40} className="mb-2" />
              <p className="text-sm">No comments yet</p>
              <p className="text-xs">Be the first to add one!</p>
            </div>
          ) : (
            <>
              {comments.map((comment) => (
                <div 
                  key={comment.id} 
                  className={`flex ${comment.authorEmail === user?.email ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                      comment.authorEmail === user?.email
                        ? 'bg-blue-500 text-white rounded-br-md'
                        : 'bg-gray-100 text-gray-700 rounded-bl-md'
                    }`}
                  >
                    {comment.authorEmail !== user?.email && (
                      <p className="text-xs font-medium mb-1 text-gray-600">
                        {comment.authorName}
                      </p>
                    )}
                    <p className="text-sm">{comment.text}</p>
                    <p className={`text-[10px] mt-1 ${
                      comment.authorEmail === user?.email ? 'text-blue-200' : 'text-gray-400'
                    }`}>
                      {comment.timestamp && formatCommentTime(comment.timestamp)}
                    </p>
                  </div>
                </div>
              ))}
              <div ref={commentsEndRef} />
            </>
          )}
        </div>

        {/* Input Area */}
        <form 
          onSubmit={handleSendComment}
          className="p-4 border-t border-gray-100"
        >
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 px-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              disabled={sendingComment}
            />
            <button
              type="submit"
              disabled={sendingComment || !newComment.trim()}
              className="p-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send size={18} />
            </button>
          </div>
          <p className="text-xs text-gray-400 mt-2 text-center">
            Comments will also appear in Family Chat
          </p>
        </form>
      </div>
    </div>
  );
};

export default CommentsModal;
