/**
 * Comments Panel Component
 * Fun, engaging comments that parents can attach to tasks
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../context/TasksContext';
import { Comment, CommentType } from '../types';
import { 
  collection, addDoc, onSnapshot, query, where, orderBy, serverTimestamp, updateDoc, doc, deleteDoc 
} from 'firebase/firestore';
import { getDbService, isDevMode } from '../services/firebase';
import { Sparkles, Heart, Zap, PartyPopper, Clown, Plus, X, Send } from 'lucide-react';

const COMMENT_TEMPLATES = [
  { type: 'encouragement' as CommentType, text: "You've got this! 🌟", animation: 'pulse' },
  { type: 'encouragement' as CommentType, text: "I believe in you! 💪", animation: 'pulse' },
  { type: 'motivational' as CommentType, text: "Time to crush this! 🔥", animation: 'bounce' },
  { type: 'motivational' as CommentType, text: "Let's do this! 🚀", animation: 'bounce' },
  { type: 'humorous' as CommentType, text: "The clock is ticking... 🕰️", animation: 'pulse' },
  { type: 'humorous' as CommentType, text: "No pressure! 😏", animation: 'pulse' },
  { type: 'celebration' as CommentType, text: "AMAZING job! 🎉", animation: 'confetti' },
  { type: 'celebration' as CommentType, text: "You're a superstar! ⭐", animation: 'confetti' },
  { type: 'silly' as CommentType, text: "Do a little dance! 💃", animation: 'bounce' },
  { type: 'silly' as CommentType, text: "Go get 'em, tiger! 🐯", animation: 'bounce' },
];

interface CommentsPanelProps {
  taskId: string;
  onClose: () => void;
}

const CommentsPanel: React.FC<CommentsPanelProps> = ({ taskId, onClose }) => {
  const { user } = useAuth();
  const { tasks } = useTasks();
  const [comments, setComments] = useState<Comment[]>([]);
  const [showTemplates, setShowTemplates] = useState(false);
  const [customText, setCustomText] = useState('');
  const [selectedType, setSelectedType] = useState<CommentType>('encouragement');
  const [selectedAnimation, setSelectedAnimation] = useState<'confetti' | 'bounce' | 'pulse' | 'slide'>('pulse');
  const [showCelebration, setShowCelebration] = useState(false);

  const task = tasks.find(t => t.id === taskId);

  // Fetch comments for this task
  useEffect(() => {
    if (isDevMode()) {
      setComments([]);
      return;
    }

    const db = getDbService();
    const commentsRef = collection(db, 'comments');
    const q = query(
      commentsRef,
      where('taskId', '==', taskId),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData: Comment[] = snapshot.docs.map(doc => ({
        ...doc.data(),
        id: doc.id,
        createdAt: doc.data().createdAt?.toDate() || new Date(),
      })) as Comment[];
      setComments(commentsData);
    });

    return () => unsubscribe();
  }, [taskId]);

  const handleAddComment = async (text: string, type: CommentType, animation: 'confetti' | 'bounce' | 'pulse' | 'slide') => {
    if (!user || !text.trim()) return;

    const newComment: Omit<Comment, 'id' | 'createdAt'> = {
      taskId,
      text: text.trim(),
      type,
      emojis: [],
      animation,
      createdBy: user.uid,
      createdByName: user.displayName || 'Parent',
      reactions: {},
    };

    await addDoc(collection(getDbService(), 'comments'), {
      ...newComment,
      createdAt: serverTimestamp(),
    });

    // Show celebration animation
    if (animation === 'confetti') {
      setShowCelebration(true);
      setTimeout(() => setShowCelebration(false), 3000);
    }

    setCustomText('');
    setShowTemplates(false);
  };

  const handleReaction = async (commentId: string, emoji: string) => {
    if (!user) return;

    const db = getDbService();
    const commentRef = doc(db, 'comments', commentId);
    const comment = comments.find(c => c.id === commentId);
    if (!comment) return;

    const reactions = { ...comment.reactions };
    if (!reactions[emoji]) reactions[emoji] = [];
    
    const userId = user.uid;
    const hasReacted = reactions[emoji].includes(userId);
    
    if (hasReacted) {
      reactions[emoji] = reactions[emoji].filter((id: string) => id !== userId);
    } else {
      reactions[emoji] = [...reactions[emoji], userId];
    }

    await updateDoc(commentRef, { reactions });
  };

  const handleDelete = async (commentId: string) => {
    if (window.confirm('Delete this comment?')) {
      await deleteDoc(doc(getDbService(), 'comments', commentId));
    }
  };

  const getAnimationStyle = (animation: string) => {
    switch (animation) {
      case 'confetti':
        return 'animate-bounce';
      case 'bounce':
        return 'animate-pulse';
      case 'pulse':
        return 'animate-pulse';
      case 'slide':
        return '';
      default:
        return '';
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-md bg-white shadow-2xl z-50 flex flex-col">
      {/* Celebration Overlay */}
      {showCelebration && (
        <div className="absolute inset-0 pointer-events-none z-50">
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 animate-pulse" />
          <div className="absolute top-1/4 left-1/4 text-6xl animate-bounce">🎉</div>
          <div className="absolute top-1/3 right-1/4 text-6xl animate-bounce delay-100">⭐</div>
          <div className="absolute bottom-1/4 left-1/3 text-6xl animate-bounce delay-200">🎊</div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center space-x-2">
          <Sparkles className="text-amber-500" size={24} />
          <h2 className="text-lg font-bold text-gray-800">Fun Comments</h2>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
          <X size={20} />
        </button>
      </div>

      {/* Task Info */}
      {task && (
        <div className="px-4 py-2 bg-amber-50 border-b">
          <p className="text-sm font-medium text-gray-700">Task: {task.title}</p>
        </div>
      )}

      {/* Comments List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {comments.length === 0 ? (
          <div className="text-center py-8 text-gray-400">
            <Sparkles size={48} className="mx-auto mb-4 opacity-50" />
            <p>No comments yet</p>
            <p className="text-sm">Add some encouragement!</p>
          </div>
        ) : (
          comments.map((comment) => (
            <div
              key={comment.id}
              className={`p-3 rounded-xl ${getAnimationStyle(comment.animation)} ${
                comment.type === 'encouragement' ? 'bg-yellow-50 border border-yellow-200' :
                comment.type === 'motivational' ? 'bg-orange-50 border border-orange-200' :
                comment.type === 'humorous' ? 'bg-gray-50 border border-gray-200' :
                comment.type === 'celebration' ? 'bg-green-50 border border-green-200' :
                'bg-purple-50 border border-purple-200'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-lg">{comment.text}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {comment.createdByName} • {comment.createdAt.toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={() => handleDelete(comment.id)}
                  className="text-gray-400 hover:text-red-500"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Reactions */}
              <div className="flex items-center space-x-1 mt-2">
                {['❤️', '😂', '👍', '🎉'].map((emoji) => {
                  const hasReacted = comment.reactions?.[emoji]?.includes(user?.uid || '');
                  return (
                    <button
                      key={emoji}
                      onClick={() => handleReaction(comment.id, emoji)}
                      className={`text-sm px-2 py-1 rounded-full ${
                        hasReacted ? 'bg-red-100' : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      {emoji} {comment.reactions?.[emoji]?.length || ''}
                    </button>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Comment Section */}
      <div className="border-t p-4">
        {/* Template Selector */}
        <div className="mb-3">
          <button
            onClick={() => setShowTemplates(!showTemplates)}
            className="flex items-center space-x-2 text-sm text-amber-600 hover:text-amber-700"
          >
            <Sparkles size={16} />
            <span>{showTemplates ? 'Hide Templates' : 'Choose a Message'}</span>
          </button>

          {showTemplates && (
            <div className="mt-3 grid grid-cols-2 gap-2">
              {COMMENT_TEMPLATES.map((template, index) => (
                <button
                  key={index}
                  onClick={() => handleAddComment(template.text, template.type, template.animation)}
                  className={`p-2 text-sm rounded-lg text-left transition-all ${
                    template.type === 'encouragement' ? 'bg-yellow-50 hover:bg-yellow-100' :
                    template.type === 'motivational' ? 'bg-orange-50 hover:bg-orange-100' :
                    template.type === 'humorous' ? 'bg-gray-50 hover:bg-gray-100' :
                    template.type === 'celebration' ? 'bg-green-50 hover:bg-green-100' :
                    'bg-purple-50 hover:bg-purple-100'
                  }`}
                >
                  {template.text}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Custom Comment Input */}
        <div className="flex items-center space-x-2">
          <div className="flex-1">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as CommentType)}
              className="text-sm border border-gray-200 rounded-lg px-2 py-1"
            >
              <option value="encouragement">💪 Encouragement</option>
              <option value="motivational">🔥 Motivational</option>
              <option value="humorous">😏 Humorous</option>
              <option value="celebration">🎉 Celebration</option>
              <option value="silly">🤪 Silly</option>
              <option value="custom">💬 Custom</option>
            </select>
          </div>
          <input
            type="text"
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder="Write a custom message..."
            className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <button
            onClick={() => handleAddComment(customText, selectedType, selectedAnimation)}
            disabled={!customText.trim()}
            className="p-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 disabled:opacity-50"
          >
            <Send size={18} />
          </button>
        </div>

        {/* Animation Type Selector */}
        <div className="flex items-center space-x-2 mt-2 text-xs text-gray-500">
          <span>Animation:</span>
          {[
            { value: 'pulse', label: '❤️ Pulse' },
            { value: 'bounce', label: '🔄 Bounce' },
            { value: 'confetti', label: '🎊 Confetti' },
          ].map(({ value, label }) => (
            <label key={value} className="flex items-center space-x-1 cursor-pointer">
              <input
                type="radio"
                name="animation"
                value={value}
                checked={selectedAnimation === value}
                onChange={(e) => setSelectedAnimation(e.target.value as typeof selectedAnimation)}
                className="text-amber-500"
              />
              <span>{label}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CommentsPanel;
