/**
 * Achievement Badge Component
 * Displays individual achievements with earned/locked states
 */

import React from 'react';
import { Achievement } from '../types';

interface AchievementBadgeProps {
  achievement: Achievement;
  earned: boolean;
  earnedDate?: Date;
  onClick: () => void;
}

const AchievementBadge: React.FC<AchievementBadgeProps> = ({ 
  achievement, 
  earned, 
  earnedDate,
  onClick 
}) => {
  return (
    <button
      onClick={onClick}
      className={`relative p-4 rounded-2xl transition-all ${
        earned
          ? 'bg-gradient-to-br from-amber-100 to-orange-100 border-2 border-amber-300 hover:scale-105'
          : 'bg-gray-100 border-2 border-gray-200 opacity-60'
      }`}
    >
      {/* Icon Background */}
      <div className={`w-16 h-16 mx-auto rounded-xl flex items-center justify-center text-3xl mb-2 ${
        earned ? 'bg-amber-200' : 'bg-gray-200'
      }`}>
        {earned ? achievement.icon : '🔒'}
      </div>

      {/* Title */}
      <h3 className={`text-sm font-bold ${earned ? 'text-gray-800' : 'text-gray-500'}`}>
        {achievement.title}
      </h3>

      {/* EP Reward */}
      <p className="text-xs text-amber-600 mt-1">
        +{achievement.epReward} EP
      </p>

      {/* Earned Date */}
      {earned && earnedDate && (
        <p className="text-[10px] text-gray-500 mt-1">
          {earnedDate.toLocaleDateString()}
        </p>
      )}

      {/* Locked Overlay */}
      {!earned && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100/50 rounded-2xl">
          <span className="text-2xl">🔒</span>
        </div>
      )}
    </button>
  );
};

export default AchievementBadge;
