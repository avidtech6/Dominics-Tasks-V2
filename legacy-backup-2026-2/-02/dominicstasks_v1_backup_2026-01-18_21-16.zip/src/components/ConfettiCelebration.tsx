/**
 * Confetti Celebration Component
 * Used for level-ups and achievement unlocks
 */

import React, { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';

interface ConfettiCelebrationProps {
  show: boolean;
  message: string;
  onComplete: () => void;
  duration?: number;
}

const ConfettiCelebration: React.FC<ConfettiCelebrationProps> = ({ 
  show, 
  message, 
  onComplete,
  duration = 3000 
}) => {
  const [particles, setParticles] = useState<Array<{
    id: number;
    x: number;
    y: number;
    color: string;
    size: number;
    delay: number;
    duration: number;
  }>>([]);

  const COLORS = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];

  useEffect(() => {
    if (!show) return;

    // Create particles
    const newParticles = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100 - 100,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      size: Math.random() * 10 + 5,
      delay: Math.random() * 0.5,
      duration: Math.random() * 1 + 1.5,
    }));

    setParticles(newParticles);

    // Auto-hide after duration
    const timer = setTimeout(() => {
      onComplete();
    }, duration);

    return () => clearTimeout(timer);
  }, [show, duration, onComplete]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 flex items-center justify-center">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/20 to-orange-500/20 animate-pulse" />

      {/* Center message */}
      <div className="relative z-10 text-center">
        <div className="animate-bounce">
          <Sparkles className="mx-auto text-amber-500" size={64} />
        </div>
        <h2 className="text-4xl font-bold bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent mt-4 animate-pulse">
          🎉 {message} 🎉
        </h2>
        <p className="text-gray-600 mt-2">Amazing work!</p>
      </div>

      {/* Confetti particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full animate-fall"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: particle.size,
            height: particle.size,
            backgroundColor: particle.color,
            animationDelay: `${particle.delay}s`,
            animationDuration: `${particle.duration}s`,
          }}
        />
      ))}

      <style>{`
        @keyframes fall {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
        .animate-fall {
          animation-name: fall;
          animation-timing-function: ease-in;
        }
      `}</style>
    </div>
  );
};

export default ConfettiCelebration;
