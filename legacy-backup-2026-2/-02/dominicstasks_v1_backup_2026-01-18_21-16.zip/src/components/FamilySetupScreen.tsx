import React, { useState, useCallback } from 'react';
import { useFamily } from '../context/FamilyContext';
import { useAuth } from '../context/AuthContext';
import {
  User,
  Lock,
  Check,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { CHILD_AVATARS, CHILD_THEME_COLORS } from '../types';

interface FamilySetupScreenProps {
  onComplete: () => void;
}

const FamilySetupScreen: React.FC<FamilySetupScreenProps> = ({ onComplete }) => {
  const { user } = useAuth();
  const { family, setupParentPin, createChildProfile } = useFamily();
  const [step, setStep] = useState(1);
  const [familyName, setFamilyName] = useState(family?.settings?.familyName || '');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [childName, setChildName] = useState('');
  const [childAvatar, setChildAvatar] = useState(CHILD_AVATARS[0]);
  const [childColor, setChildColor] = useState(CHILD_THEME_COLORS[0]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFamilyNameSubmit = useCallback(() => {
    if (!familyName.trim()) {
      setError('Please enter a family name');
      return;
    }
    setError(null);
    setStep(2);
  }, [familyName]);

  const handlePinSubmit = useCallback(() => {
    if (pin.length !== 4) {
      setError('PIN must be 4 digits');
      return;
    }
    if (pin !== confirmPin) {
      setError('PINs do not match');
      return;
    }
    if (!/^\d+$/.test(pin)) {
      setError('PIN must contain only numbers');
      return;
    }
    setError(null);
    setStep(3);
  }, [pin, confirmPin]);

  const handleCreateProfile = useCallback(async () => {
    if (!childName.trim()) {
      setError('Please enter your child\'s name');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Update family name
      await updateFamilySettings({ familyName: familyName.trim() });
      
      // Setup PIN
      await setupParentPin(pin);
      
      // Create first child profile
      await createChildProfile(childName.trim(), childAvatar, childColor);
      
      onComplete();
    } catch (err) {
      setError('Failed to complete setup. Please try again.');
      console.error('Setup error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [childName, childAvatar, childColor, familyName, pin, setupParentPin, createChildProfile, onComplete]);

  // Need to create a local update function since we're not importing the full updateParentSettings
  const updateFamilySettings = async (updates: { familyName: string }) => {
    // This will be handled by the parent component
  };

  return (
    <div className="family-setup-screen">
      {/* Progress indicator */}
      <div className="setup-progress">
        <div className={`progress-step ${step >= 1 ? 'active' : ''} ${step > 1 ? 'completed' : ''}`}>
          <div className="step-number">{step > 1 ? <Check size={16} /> : '1'}</div>
          <span>Family Name</span>
        </div>
        <div className="progress-line" />
        <div className={`progress-step ${step >= 2 ? 'active' : ''} ${step > 2 ? 'completed' : ''}`}>
          <div className="step-number">{step > 2 ? <Check size={16} /> : '2'}</div>
          <span>Parent PIN</span>
        </div>
        <div className="progress-line" />
        <div className={`progress-step ${step >= 3 ? 'active' : ''}`}>
          <div className="step-number">3</div>
          <span>First Child</span>
        </div>
      </div>

      {/* Step 1: Family Name */}
      {step === 1 && (
        <div className="setup-step">
          <div className="step-icon">
            <User size={48} />
          </div>
          <h1>Welcome to Dominic's Tasks!</h1>
          <p>Let's set up your family account in just a few steps.</p>

          <div className="form-group">
            <label>Your Family Name</label>
            <input
              type="text"
              value={familyName}
              onChange={(e) => setFamilyName(e.target.value)}
              placeholder="The Giles Family"
              maxLength={30}
              autoFocus
            />
            <span className="input-hint">This name will appear on your family dashboard</span>
          </div>

          {error && <div className="error-message">{error}</div>}

          <button className="primary-btn" onClick={handleFamilyNameSubmit}>
            Continue
            <ChevronRight size={20} />
          </button>
        </div>
      )}

      {/* Step 2: Parent PIN */}
      {step === 2 && (
        <div className="setup-step">
          <div className="step-icon lock-icon">
            <Lock size={48} />
          </div>
          <h1>Set Parent PIN</h1>
          <p>Create a 4-digit PIN to access parent controls and settings.</p>

          <div className="form-group">
            <label>Enter PIN</label>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="1234"
              maxLength={4}
              className="pin-input"
              autoFocus
            />
          </div>

          <div className="form-group">
            <label>Confirm PIN</label>
            <input
              type="password"
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="1234"
              maxLength={4}
              className="pin-input"
            />
          </div>

          {error && <div className="error-message">{error}</div>}

          <div className="button-group">
            <button className="secondary-btn" onClick={() => setStep(1)}>
              Back
            </button>
            <button className="primary-btn" onClick={handlePinSubmit}>
              Continue
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: First Child */}
      {step === 3 && (
        <div className="setup-step">
          <div className="step-icon sparkles-icon">
            <Sparkles size={48} />
          </div>
          <h1>Add Your First Child</h1>
          <p>Create a profile for your child to start tracking tasks and earning rewards.</p>

          <div className="form-group">
            <label>Child's Name</label>
            <input
              type="text"
              value={childName}
              onChange={(e) => setChildName(e.target.value)}
              placeholder="Enter name"
              maxLength={20}
              autoFocus
            />
          </div>

          <div className="form-group">
            <label>Choose Avatar</label>
            <div className="avatar-grid">
              {CHILD_AVATARS.map((avatar) => (
                <button
                  key={avatar}
                  className={`avatar-option ${childAvatar === avatar ? 'selected' : ''}`}
                  onClick={() => setChildAvatar(avatar)}
                >
                  {avatar}
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label>Theme Color</label>
            <div className="color-grid">
              {CHILD_THEME_COLORS.map((color) => (
                <button
                  key={color}
                  className={`color-option ${childColor === color ? 'selected' : ''}`}
                  style={{ backgroundColor: color }}
                  onClick={() => setChildColor(color)}
                />
              ))}
            </div>
          </div>

          {/* Preview */}
          <div className="preview-section">
            <label>Preview</label>
            <div className="preview-card" style={{ borderColor: childColor }}>
              <div className="preview-avatar">{childAvatar}</div>
              <div className="preview-info">
                <div className="preview-name">{childName || 'Child Name'}</div>
                <div className="preview-theme" style={{ color: childColor }}>Custom Theme</div>
              </div>
            </div>
          </div>

          {error && <div className="error-message">{error}</div>}

          <div className="button-group">
            <button className="secondary-btn" onClick={() => setStep(2)} disabled={isLoading}>
              Back
            </button>
            <button className="primary-btn" onClick={handleCreateProfile} disabled={isLoading}>
              {isLoading ? 'Setting up...' : 'Complete Setup'}
            </button>
          </div>
        </div>
      )}

      <style>{`
        .family-setup-screen {
          min-height: 100vh;
          background: linear-gradient(180deg, #F0F9FF 0%, #E0F2FE 100%);
          display: flex;
          flex-direction: column;
          padding: 24px;
        }

        .setup-progress {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          margin-bottom: 40px;
          padding-top: 20px;
        }

        .progress-step {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .step-number {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: #E5E7EB;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          font-weight: 600;
          color: #6B7280;
          transition: all 0.2s;
        }

        .progress-step.active .step-number {
          background: #3B82F6;
          color: white;
        }

        .progress-step.completed .step-number {
          background: #10B981;
          color: white;
        }

        .progress-step span {
          font-size: 12px;
          color: #6B7280;
          font-weight: 500;
        }

        .progress-step.active span {
          color: #374151;
        }

        .progress-line {
          width: 40px;
          height: 2px;
          background: #E5E7EB;
          margin-bottom: 20px;
        }

        .setup-step {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          max-width: 420px;
          margin: 0 auto;
          text-align: center;
        }

        .step-icon {
          width: 80px;
          height: 80px;
          background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
          border-radius: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          margin-bottom: 24px;
          box-shadow: 0 8px 24px rgba(59, 130, 246, 0.3);
        }

        .step-icon.lock-icon {
          background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);
          box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        .step-icon.sparkles-icon {
          background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);
          box-shadow: 0 8px 24px rgba(245, 158, 11, 0.3);
        }

        .setup-step h1 {
          font-size: 28px;
          font-weight: 700;
          color: #111827;
          margin: 0 0 8px;
        }

        .setup-step p {
          font-size: 16px;
          color: #6B7280;
          margin: 0 0 32px;
          line-height: 1.5;
        }

        .form-group {
          width: 100%;
          margin-bottom: 20px;
          text-align: left;
        }

        .form-group label {
          display: block;
          font-size: 14px;
          font-weight: 500;
          color: #374151;
          margin-bottom: 8px;
        }

        .form-group input {
          width: 100%;
          padding: 14px 16px;
          border: 1px solid #D1D5DB;
          border-radius: 12px;
          font-size: 16px;
          transition: all 0.2s;
        }

        .form-group input:focus {
          outline: none;
          border-color: #3B82F6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .pin-input {
          font-size: 24px;
          font-weight: 600;
          text-align: center;
          letter-spacing: 8px;
        }

        .input-hint {
          display: block;
          font-size: 12px;
          color: #9CA3AF;
          margin-top: 4px;
        }

        .avatar-grid {
          display: grid;
          grid-template-columns: repeat(6, 1fr);
          gap: 8px;
        }

        .avatar-option {
          aspect-ratio: 1;
          border: 2px solid #E5E7EB;
          border-radius: 12px;
          background: white;
          font-size: 24px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .avatar-option:hover {
          border-color: #3B82F6;
          background: #EFF6FF;
        }

        .avatar-option.selected {
          border-color: #3B82F6;
          background: #EFF6FF;
          box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
        }

        .color-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 8px;
        }

        .color-option {
          aspect-ratio: 1;
          border: 3px solid transparent;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.2s;
        }

        .color-option:hover {
          transform: scale(1.05);
        }

        .color-option.selected {
          border-color: #111827;
        }

        .preview-section {
          width: 100%;
          text-align: left;
          margin-bottom: 16px;
        }

        .preview-section label {
          display: block;
          font-size: 14px;
          font-weight: 500;
          color: #374151;
          margin-bottom: 8px;
        }

        .preview-card {
          display: flex;
          align-items: center;
          gap: 16px;
          padding: 16px;
          background: white;
          border-radius: 16px;
          border: 2px solid;
        }

        .preview-avatar {
          font-size: 36px;
          width: 56px;
          height: 56px;
          background: #F3F4F6;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .preview-info {
          text-align: left;
        }

        .preview-name {
          font-size: 18px;
          font-weight: 600;
          color: #111827;
        }

        .preview-theme {
          font-size: 13px;
          font-weight: 500;
        }

        .error-message {
          width: 100%;
          padding: 12px;
          background: #FEF2F2;
          border: 1px solid #FECACA;
          border-radius: 8px;
          color: #DC2626;
          font-size: 14px;
          margin-bottom: 16px;
        }

        .primary-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
          border: none;
          border-radius: 14px;
          color: white;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .primary-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(59, 130, 246, 0.4);
        }

        .primary-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .secondary-btn {
          flex: 1;
          padding: 16px;
          background: #F3F4F6;
          border: none;
          border-radius: 14px;
          color: #374151;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }

        .secondary-btn:hover:not(:disabled) {
          background: #E5E7EB;
        }

        .secondary-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .button-group {
          display: flex;
          gap: 12px;
          width: 100%;
          margin-top: auto;
        }

        @media (max-width: 480px) {
          .avatar-grid {
            grid-template-columns: repeat(4, 1fr);
          }

          .setup-progress {
            transform: scale(0.9);
          }
        }
      `}</style>
    </div>
  );
};

export default FamilySetupScreen;
