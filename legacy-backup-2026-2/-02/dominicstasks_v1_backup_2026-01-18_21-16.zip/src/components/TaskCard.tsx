import React, { useState } from 'react';
import { useTasks } from '../context/TasksContext';
import { Task } from '../types';
import { getTaskTypeConfig, getPriorityConfig, getDeadlineStatus, getDaysUntilDeadline } from '../utils';
import { Check, Calendar, MoreVertical, Edit, Trash2, MessageCircle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  showActions?: boolean;
  onEdit?: () => void;
  onAddComment?: () => void;
  onOpenComments?: () => void; // NEW: Open comments modal
}

const TaskCard: React.FC<TaskCardProps> = ({
  task,
  showActions = true,
  onEdit,
  onAddComment,
  onOpenComments, // NEW
}) => {
  const { completeTask, deleteTask } = useTasks();
  const [showMenu, setShowMenu] = useState(false);

  const typeConfig = getTaskTypeConfig(task.taskType);
  const priorityConfig = getPriorityConfig(task.priority);
  const deadlineStatus = getDeadlineStatus(task.deadlineDate, task.status);
  const daysUntilDeadline = getDaysUntilDeadline(task.deadlineDate);

  const handleComplete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await completeTask(task.id);
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this task?')) {
      await deleteTask(task.id);
    }
    setShowMenu(false);
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    onEdit?.();
    setShowMenu(false);
  };

  const handleAddComment = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddComment?.();
    setShowMenu(false);
  };

  return (
    <div
      className={`bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-all duration-200 task-type-${task.taskType}`}
    >
      <div className="flex items-start space-x-3">
        {/* Complete Button */}
        {showActions && task.status !== 'done' && (
          <button
            onClick={handleComplete}
            className="mt-1 w-6 h-6 rounded-full border-2 border-gray-300 hover:border-green-500 hover:bg-green-500 transition-colors flex-shrink-0 flex items-center justify-center"
          >
            <Check className="text-white opacity-0 hover:opacity-100" size={14} />
          </button>
        )}

        {/* Task Content */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-lg">{typeConfig.icon}</span>
            <span
              className="text-xs px-2 py-1 rounded-full font-medium"
              style={{
                backgroundColor: `${typeConfig.color}20`,
                color: typeConfig.color,
              }}
            >
              {typeConfig.label}
            </span>
            <span
              className="text-xs px-2 py-1 rounded-full font-medium"
              style={{
                backgroundColor: `${priorityConfig.color}20`,
                color: priorityConfig.color,
              }}
            >
              {priorityConfig.label}
            </span>
          </div>

          {/* Title */}
          <h3
            className={`font-semibold text-gray-800 mb-1 ${
              task.status === 'done' ? 'line-through text-gray-400' : ''
            }`}
          >
            {task.title}
          </h3>

          {/* Description */}
          {task.description && (
            <p className="text-sm text-gray-500 mb-2 line-clamp-2">
              {task.description}
            </p>
          )}

          {/* Tags */}
          {task.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {task.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="text-xs px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full"
                >
                  #{tag}
                </span>
              ))}
              {task.tags.length > 3 && (
                <span className="text-xs text-gray-400">
                  +{task.tags.length - 3}
                </span>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center space-x-3">
              {/* Deadline */}
              {task.deadlineDate && (
                <div className="flex items-center space-x-1">
                  <Calendar size={14} />
                  <span>
                    {deadlineStatus === 'overdue'
                      ? `Overdue by ${Math.abs(daysUntilDeadline || 0)} days`
                      : deadlineStatus === 'urgent'
                      ? 'Due tomorrow!'
                      : daysUntilDeadline === 0
                      ? 'Due today'
                      : `${daysUntilDeadline} days left`}
                  </span>
                </div>
              )}

              {/* Points */}
              <div className="flex items-center space-x-1">
                <span className="text-amber-500">⭐</span>
                <span>{task.pointsValue} EP</span>
              </div>
            </div>

            {/* Comment count badge - clickable to open comments modal */}
            {(task.commentCount || 0) > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenComments?.();
                }}
                className="flex items-center space-x-1 text-gray-500 bg-gray-100 px-2 py-1 rounded-full hover:bg-gray-200 transition-colors"
              >
                <MessageCircle size={14} />
                <span className="font-medium">{task.commentCount}</span>
              </button>
            )}

            {/* Actions Menu */}
            {showActions && (
              <div className="relative">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowMenu(!showMenu);
                  }}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  <MoreVertical size={16} />
                </button>

                {showMenu && (
                  <div className="absolute right-0 top-8 bg-white rounded-xl shadow-lg border border-gray-200 py-1 z-10 min-w-[140px]">
                    <button
                      onClick={handleEdit}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50"
                    >
                      <Edit size={14} />
                      <span>Edit</span>
                    </button>
                    {onAddComment && (
                      <button
                        onClick={handleAddComment}
                        className="w-full flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50"
                      >
                        <MessageCircle size={14} />
                        <span>Add Comment</span>
                      </button>
                    )}
                    <button
                      onClick={handleDelete}
                      className="w-full flex items-center space-x-2 px-4 py-2 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 size={14} />
                      <span>Delete</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
