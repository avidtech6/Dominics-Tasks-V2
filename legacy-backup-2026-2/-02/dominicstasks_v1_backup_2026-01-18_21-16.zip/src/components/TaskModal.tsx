import React, { useState, useEffect } from 'react';
import { useTasks } from '../context/TasksContext';
import { useAuth } from '../context/AuthContext';
import { Task, TaskType, TaskPriority, TaskSection } from '../types';
import { X, Calendar, Trophy, Flag, MessageCircle, Send } from 'lucide-react';
import { format } from 'date-fns';
import { isDevMode } from '../services/devMode';

interface TaskModalProps {
  onClose: () => void;
  taskToEdit?: Task | null;
}

const TaskModal: React.FC<TaskModalProps> = ({ onClose, taskToEdit }) => {
  const { user } = useAuth();
  const { addTask, updateTask, addTaskComment, getTaskComments } = useTasks();
  
  // Tab state
  const [activeTab, setActiveTab] = useState<'details' | 'comments'>('details');
  
  // Comment state
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [sendingComment, setSendingComment] = useState(false);

  // Fetch comments when editing an existing task
  useEffect(() => {
    if (taskToEdit?.id && !isDevMode()) {
      const fetchComments = async () => {
        try {
          const fetchedComments = await getTaskComments(taskToEdit.id);
          setComments(fetchedComments);
        } catch (error) {
          console.error('Error fetching comments:', error);
        }
      };
      fetchComments();
    }
  }, [taskToEdit?.id]);

  // Handle adding a new comment
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !taskToEdit?.id || !user) return;

    setSendingComment(true);
    try {
      await addTaskComment(taskToEdit.id, taskToEdit.title, newComment.trim());
      
      // Refresh comments list
      const fetchedComments = await getTaskComments(taskToEdit.id);
      setComments(fetchedComments);
      
      setNewComment('');
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setSendingComment(false);
    }
  };

  // Format comment time
  const formatCommentTime = (date: Date) => {
    return format(date, 'MMM d, h:mm a');
  };

  // Safe date formatting
  const safeFormatDate = (date: unknown): string => {
    if (!date) return '';
    try {
      const d = date instanceof Date ? date : new Date(String(date));
      if (isNaN(d.getTime())) return '';
      return d.toISOString().split('T')[0];
    } catch {
      return '';
    }
  };

  const [title, setTitle] = useState(taskToEdit?.title || '');
  const [description, setDescription] = useState(taskToEdit?.description || '');
  const [taskType, setTaskType] = useState<TaskType>(taskToEdit?.taskType || 'regular');
  const [priority, setPriority] = useState<TaskPriority>(taskToEdit?.priority || 'medium');
  const [section, setSection] = useState<TaskSection>(taskToEdit?.section || 'morning');
  const [dueDate, setDueDate] = useState(safeFormatDate(taskToEdit?.dueDate));
  const [deadlineDate, setDeadlineDate] = useState(safeFormatDate(taskToEdit?.deadlineDate));
  const [pointsValue, setPointsValue] = useState(
    taskToEdit?.pointsValue ? String(taskToEdit.pointsValue) : '50'
  );
  const [selectedTags, setSelectedTags] = useState<string[]>(taskToEdit?.tags || []);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Task type options - simple array instead of object.entries to avoid issues
  const taskTypeOptions: { value: TaskType; label: string; icon: string; points: number }[] = [
    { value: 'regular', label: 'Regular', icon: '📋', points: 50 },
    { value: 'assignment', label: 'Assignment', icon: '📝', points: 100 },
    { value: 'exam', label: 'Exam', icon: '🎯', points: 200 },
    { value: 'project', label: 'Project', icon: '🚀', points: 300 },
    { value: 'personal', label: 'Personal', icon: '⭐', points: 25 },
  ];

  // Priority options
  const priorityOptions: { value: TaskPriority; label: string }[] = [
    { value: 'low', label: 'Low' },
    { value: 'medium', label: 'Medium' },
    { value: 'high', label: 'High' },
    { value: 'urgent', label: 'Urgent' },
  ];

  // Section options
  const sectionOptions: { value: TaskSection; label: string }[] = [
    { value: 'morning', label: 'Morning' },
    { value: 'afternoon', label: 'Afternoon' },
    { value: 'assignments', label: 'Assignments' },
    { value: 'leftovers', label: 'Left Over' },
    { value: 'experiments', label: 'Experiments' },
    { value: 'support', label: 'Support & Activities' },
  ];

  // Available tags for selection
  const availableTags = ['ASAP', 'Important', 'Leftover', 'Support', 'Fun', 'Study', 'Math', 'Science', 'English', 'CS'];

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  // Auto-set due date when section changes to morning or afternoon
  const handleSectionChange = (newSection: TaskSection) => {
    setSection(newSection);
    // Auto-set due date to today if moving to morning or afternoon
    if ((newSection === 'morning' || newSection === 'afternoon') && !dueDate) {
      setDueDate(new Date().toISOString().split('T')[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setError('Please enter a task title');
      return;
    }

    if (!user) {
      setError('You must be logged in');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      // Build task data object, using null instead of undefined for optional fields
      const taskData: Omit<Task, 'id' | 'createdAt' | 'createdBy' | 'order'> = {
        title: title.trim(),
        description: description.trim() || null,
        taskType,
        priority,
        section,
        status: taskToEdit?.status || 'todo',
        tags: selectedTags,
        pointsValue: parseInt(pointsValue, 10) || 50,
        completedAt: taskToEdit?.completedAt || null,
        // Use null instead of undefined for optional date fields
        // For morning/afternoon sections, always set due date to today if not specified
        dueDate: (section === 'morning' || section === 'afternoon') 
          ? (dueDate ? new Date(dueDate) : new Date())
          : (dueDate ? new Date(dueDate) : null),
        deadlineDate: deadlineDate ? new Date(deadlineDate) : null,
      };

      if (taskToEdit?.id) {
        // For updates, include the order field
        await updateTask(taskToEdit.id, { ...taskData, order: taskToEdit.order || 0 });
      } else {
        await addTask(taskData);
      }

      onClose();
    } catch (err) {
      console.error('Error saving task:', err);
      setError('Failed to save task. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };



  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-800">
            {taskToEdit ? 'Edit Task' : 'Add New Task'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X size={20} className="text-gray-500" />
          </button>
        </div>

        {/* Tabs Navigation - Only show when editing existing task */}
        {taskToEdit?.id && (
          <div className="flex border-b border-gray-100">
            <button
              type="button"
              onClick={() => setActiveTab('details')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'details'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Details
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('comments')}
              className={`flex-1 py-3 text-sm font-medium transition-colors ${
                activeTab === 'comments'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Comments ({comments.length})
            </button>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Error message */}
          {error && (
            <div style={{
              background: '#fff5f5',
              color: '#c53030',
              padding: '12px 16px',
              borderRadius: '8px',
              fontSize: '0.9rem',
              border: '1px solid #feb2b2'
            }}>
              {error}
            </div>
          )}

          {/* Tab 1: Details */}
          <div className={taskToEdit?.id && activeTab === 'comments' ? 'hidden' : ''}>
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Task Title *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="What needs to be done?"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Description
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add more details..."
              rows={2}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          {/* Task Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trophy className="inline w-4 h-4 mr-1" />
              Task Type
            </label>
            <div className="grid grid-cols-3 gap-2">
              {taskTypeOptions.map((type) => (
                <button
                  key={type.value}
                  type="button"
                  onClick={() => {
                    setTaskType(type.value);
                    setPointsValue(type.points.toString());
                  }}
                  className={`p-2 rounded-xl border-2 transition-all text-center ${
                    taskType === type.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="text-xl">{type.icon}</div>
                  <div className="text-xs mt-1">{type.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Section and Priority */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Section
              </label>
              <select
                value={section}
                onChange={(e) => handleSectionChange(e.target.value as TaskSection)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {sectionOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Flag className="inline w-4 h-4 mr-1" />
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as TaskPriority)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {priorityOptions.map((opt) => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="inline w-4 h-4 mr-1" />
                Due
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="inline w-4 h-4 mr-1" />
                Deadline
              </label>
              <input
                type="date"
                value={deadlineDate}
                onChange={(e) => setDeadlineDate(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* EP Value */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Trophy className="inline w-4 h-4 mr-1" />
              EP Value
            </label>
            <input
              type="number"
              value={pointsValue}
              onChange={(e) => setPointsValue(e.target.value)}
              min="1"
              max="1000"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tags
            </label>
            <div className="flex flex-wrap gap-2">
              {availableTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                    selectedTags.includes(tag)
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
            {selectedTags.length > 0 && (
              <div className="mt-2 text-sm text-gray-500">
                Selected: {selectedTags.map(t => `#${t}`).join(' ')}
              </div>
            )}
          </div>
          </div> {/* End of Details tab */}

          {/* Tab 2: Comments - only show when editing existing task */}
          {taskToEdit?.id && activeTab === 'comments' && (
            <div>
              <div className="max-h-64 overflow-y-auto space-y-2 mb-4">
                {comments.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-8 text-gray-400">
                    <MessageCircle size={40} className="mb-2" />
                    <p className="text-sm">No comments yet</p>
                    <p className="text-xs">Be the first to add one!</p>
                  </div>
                ) : (
                  comments.map((comment) => (
                    <div 
                      key={comment.id} 
                      className={`p-3 rounded-lg ${
                        comment.authorEmail === user?.email
                          ? 'bg-blue-50 ml-8'
                          : 'bg-gray-50 mr-8'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-gray-700">
                          {comment.authorName}
                        </span>
                        <span className="text-xs text-gray-400">
                          {comment.timestamp && formatCommentTime(comment.timestamp)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{comment.text}</p>
                    </div>
                  ))
                )}
              </div>

              {/* Add Comment Form */}
              <form onSubmit={handleAddComment} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add a comment..."
                  className="flex-1 px-4 py-2 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                />
                <button
                  type="submit"
                  disabled={sendingComment || !newComment.trim()}
                  className="p-2 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send size={18} />
                </button>
              </form>
              <p className="text-xs text-gray-400 mt-2 text-center">
                Comments will also appear in Family Chat
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-200 text-gray-600 rounded-xl font-medium hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !title.trim()}
              className="flex-1 px-6 py-3 bg-blue-500 text-white rounded-xl font-medium hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Saving...' : taskToEdit ? 'Update Task' : 'Add Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskModal;
