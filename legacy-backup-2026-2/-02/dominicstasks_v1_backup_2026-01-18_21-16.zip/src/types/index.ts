// Task Types
export type TaskType = 'regular' | 'assignment' | 'exam' | 'project' | 'personal';

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export type TaskStatus = 'todo' | 'today' | 'done';

export type TaskSection =
  | 'morning'
  | 'afternoon'
  | 'assignments'
  | 'leftovers'
  | 'experiments'
  | 'support'
  | 'catchup';

export interface Task {
  id: string;
  title: string;
  description?: string | null;
  dueDate?: Date | null;
  deadlineDate?: Date | null;
  status: TaskStatus;
  section: TaskSection;
  taskType: TaskType;
  priority: TaskPriority;
  tags: string[];
  createdBy: string;
  createdAt: Date;
  pointsValue: number;
  completedAt?: Date | null;
  archivedAt?: Date | null;
  deletedAt?: Date | null;
  order: number;
  commentCount?: number; // Denormalized comment count for quick display
}

// NEW: Extended task type for mirrored tasks
export interface MirroredTask extends Task {
  isMirrored: boolean;
  originalSection: string;
}

// Task Type Configuration
export interface TaskTypeConfig {
  icon: string;
  label: string;
  color: string;
  defaultPoints: number;
  hasDeadline: boolean;
}

export const TASK_TYPES: Record<TaskType, TaskTypeConfig> = {
  regular: {
    icon: '📋',
    label: 'Regular Task',
    color: '#3B82F6',
    defaultPoints: 50,
    hasDeadline: false,
  },
  assignment: {
    icon: '📝',
    label: 'Assignment',
    color: '#8B5CF6',
    defaultPoints: 100,
    hasDeadline: true,
  },
  exam: {
    icon: '🎯',
    label: 'Exam/Quiz',
    color: '#EF4444',
    defaultPoints: 200,
    hasDeadline: true,
  },
  project: {
    icon: '🚀',
    label: 'Project',
    color: '#F59E0B',
    defaultPoints: 300,
    hasDeadline: true,
  },
  personal: {
    icon: '⭐',
    label: 'Personal Goal',
    color: '#10B981',
    defaultPoints: 25,
    hasDeadline: false,
  },
};

// Priority Configuration
export interface PriorityConfig {
  color: string;
  label: string;
}

export const PRIORITY_LEVELS: Record<TaskPriority, PriorityConfig> = {
  low: { color: '#6B7280', label: 'Low' },
  medium: { color: '#3B82F6', label: 'Medium' },
  high: { color: '#F59E0B', label: 'High' },
  urgent: { color: '#EF4444', label: 'Urgent' },
};

// Tag Configuration
export interface Tag {
  id: string;
  label: string;
  color: string;
}

export const DEFAULT_TAGS: Tag[] = [
  { id: 'math', label: 'Math', color: '#EF4444' },
  { id: 'science', label: 'Science', color: '#10B981' },
  { id: 'english', label: 'English', color: '#3B82F6' },
  { id: 'history', label: 'History', color: '#F59E0B' },
  { id: 'computerscience', label: 'Computer Science', color: '#8B5CF6' },
  { id: 'art', label: 'Art', color: '#EC4899' },
  { id: 'homework', label: 'Homework', color: '#6366F1' },
  { id: 'classwork', label: 'Classwork', color: '#14B8A6' },
  { id: 'study', label: 'Study', color: '#F97316' },
  { id: 'reading', label: 'Reading', color: '#0EA5E9' },
];

// User Types
export type UserRole = 'student' | 'parent';

export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  currentStreak: number;
  totalEP: number;
  level: number;
  unlockedAchievements: string[];
}

// Comment Types
export type CommentType =
  | 'encouragement'
  | 'motivational'
  | 'humorous'
  | 'celebration'
  | 'silly'
  | 'custom';

export interface Comment {
  id: string;
  taskId: string;
  text: string;
  type: CommentType;
  emojis: string[];
  animation: 'confetti' | 'bounce' | 'pulse' | 'slide';
  createdBy: string;
  createdByName: string;
  createdAt: Date;
  reactions: Record<string, string>; // userId -> emoji
}

// Message Types
export interface Message {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderEmail: string;
  timestamp: Date;
  type: 'user' | 'system';
  systemEvent?: string;
  attachments?: Attachment[];
  edited?: boolean;
  editedAt?: Date;
  reactions?: Record<string, string[]>; // emoji -> userIds
}

export interface PrivateMessage {
  id: string;
  conversationId: string;
  text: string;
  senderId: string;
  senderName: string;
  senderEmail: string;
  timestamp: Date;
  readBy: string[];
  attachments?: Attachment[];
  edited?: boolean;
  editedAt?: Date;
  reactions?: Record<string, string[]>; // emoji -> userIds
}

// Resource Types
export interface Resource {
  id: string;
  title: string;
  driveUrl: string;
  fileType: string;
  addedBy: string;
  addedByName: string;
  addedAt: Date;
}

export interface Attachment {
  id: string;
  title: string;
  url: string;
  fileType: 'image' | 'video' | 'document' | 'audio';
  thumbnailUrl?: string;
  fileSize?: number;
}

// Common emojis for quick reactions
export const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🎉'];

// Achievement Types
export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  epReward: number;
  category: 'daily' | 'subject' | 'time' | 'special';
  requirement: (user: User, tasks: Task[]) => boolean;
}

// Gamification Constants
export const EP_PER_LEVEL = 1000;
export const BASE_EP_PER_TASK = 50;
export const STREAK_BONUS_EP = 25;
export const STREAK_BONUS_PER_DAY = 5;

// ============================================
// MULTI-CHILD FAMILY ARCHITECTURE
// ============================================

// Avatar options for children
export const CHILD_AVATARS = [
  '🦁', '🐯', '🐻', '🐨', '🐼', '🐸', '🦊', '🐰',
  '🦄', '🐳', '🦋', '🐞', '🐝', '🦉', '🐙', '🦎',
  '🚀', '⭐', '🌟', '💫', '🎨', '🎭', '🎪', '🎯'
];

// Theme colors for children
export const CHILD_THEME_COLORS = [
  '#3B82F6', // blue
  '#10B981', // green
  '#F59E0B', // amber
  '#EF4444', // red
  '#8B5CF6', // purple
  '#EC4899', // pink
  '#06B6D4', // cyan
  '#84CC16', // lime
];

export type ProfileMode = 'child' | 'parent';

export interface ChildProfile {
  id: string;
  name: string;
  avatar: string;
  themeColor: string;
  age?: number;
  stats: {
    totalEP: number;
    level: number;
    currentStreak: number;
    tasksCompleted: number;
    totalTasks: number;
  };
  settings: ChildSettings;
  createdAt: Date;
  updatedAt: Date;
}

export interface ChildSettings {
  pointsEnabled: boolean;
  morningBonusEnabled: boolean;
  morningBonusDeadline: string; // HH:MM format, default "13:00"
  deadlineWarningsEnabled: boolean;
  autoAfternoonMoveEnabled: boolean;
  autoAfternoonMoveTime: string; // HH:MM format, default "13:00"
  timerEnabled: boolean;
  historyEnabled: boolean;
  doTomorrowEnabled: boolean;
  shopEnabled: boolean;
  leaderboardEnabled: boolean;
  achievementsEnabled: boolean;
  defaultApprovalLevel: ApprovalLevel;
}

export type ApprovalLevel = 0 | 1 | 2 | 3;

export const APPROVAL_LEVELS: Record<ApprovalLevel, { label: string; description: string }> = {
  0: { label: 'No Approval Required', description: 'Points awarded immediately upon task completion' },
  1: { label: 'Light Verification', description: 'Points held for 24 hours unless parent rejects' },
  2: { label: 'Parent Approval Required', description: 'Parent must review and approve before points awarded' },
  3: { label: 'Evidence Required', description: 'Child must upload evidence before parent review' },
};

export interface FamilySettings {
  parentId: string;
  hasPinSetup: boolean;
  pinHash?: string; // SHA-256 hash of PIN
  biometricEnabled: boolean;
  familyName: string;
  theme: 'light' | 'dark';
  notificationsEnabled: boolean;
  emailNotificationsEnabled: boolean;
}

export interface Family {
  id: string;
  settings: FamilySettings;
  children: Record<string, ChildProfile>;
  createdAt: Date;
  updatedAt: Date;
}

// Task approval status
export type ApprovalStatus = 'pending' | 'approved' | 'rejected';

export interface TaskApproval {
  taskId: string;
  childId: string;
  status: ApprovalStatus;
  level: ApprovalLevel;
  evidenceUrl?: string;
  evidenceType?: 'image' | 'document' | 'text';
  parentNote?: string;
  reviewedBy?: string;
  reviewedAt?: Date;
  createdAt: Date;
}

// Reward types
export interface Reward {
  id: string;
  childId?: string; // If undefined, available to all children
  name: string;
  description: string;
  cost: number;
  type: 'privilege' | 'screen_time' | 'item' | 'custom';
  isActive: boolean;
  createdAt: Date;
}

// Daily summary for a child
export interface DailySummary {
  id: string;
  childId: string;
  date: Date;
  tasksCompleted: number;
  tasksCreated: number;
  totalEP: number;
  streakContinued: boolean;
  morningBonusEarned: boolean;
  approvalRequired: number;
  approvalPending: number;
  approvalApproved: number;
  approvalRejected: number;
}
