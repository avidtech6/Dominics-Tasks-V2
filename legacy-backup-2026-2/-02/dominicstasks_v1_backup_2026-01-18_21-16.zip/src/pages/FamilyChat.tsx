import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, 
  limit, doc, updateDoc, deleteDoc
} from 'firebase/firestore';
import { getDbService, isDevMode, uploadChatAttachment } from '../services/firebase';
import { Message, Attachment } from '../types';
import { format } from 'date-fns';
import { 
  Paperclip, Smile, MessageCircle, 
  MoreVertical, Edit2, Trash2, Check, X,
  Camera, Plus
} from 'lucide-react';
import { QUICK_REACTIONS } from '../types';

const FamilyChat: React.FC = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showActions, setShowActions] = useState<string | null>(null);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);
  const [editText, setEditText] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [showMobileActions, setShowMobileActions] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Admin users can delete ANY message
  const ADMIN_EMAILS = ['derrickmg.admin@gmail.com', 'brendamgiles@gmail.com'];
  const isAdmin = user?.email && ADMIN_EMAILS.includes(user.email);

  // Fetch messages in real-time
  useEffect(() => {
    // Skip Firestore connection in dev mode
    if (isDevMode()) {
      console.log('🔧 DEV MODE: Skipping family messages loading');
      return;
    }

    const db = getDbService();
    const messagesRef = collection(db, 'family_messages');
    const q = query(messagesRef, orderBy('timestamp', 'asc'), limit(100));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messagesData: Message[] = snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          timestamp: data.timestamp?.toDate() || new Date(),
        } as Message;
      });
      setMessages(messagesData);
    });

    return () => unsubscribe();
  }, []);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if ((!newMessage.trim() && attachments.length === 0) || !user) return;

    setSending(true);
    setUploadProgress(0);

    try {
      const messageId = `${Date.now()}-${user.uid}`;
      const attachmentsData: Attachment[] = [];

      // Upload attachments with progress tracking
      const totalFiles = attachments.length;
      for (let i = 0; i < attachments.length; i++) {
        const file = attachments[i];
        console.log(`Uploading file ${i + 1} of ${totalFiles}:`, file.name);
        
        const uploaded = await uploadChatAttachment(file, 'family', messageId, (progress) => {
          // Calculate overall progress
          const fileProgress = progress / totalFiles;
          const baseProgress = (i / totalFiles) * 100;
          setUploadProgress(baseProgress + fileProgress);
        });
        
        attachmentsData.push({
          id: `${Date.now()}-${Math.random()}`,
          title: file.name,
          url: uploaded.url,
          fileType: uploaded.fileType as 'image' | 'video' | 'document' | 'audio',
        });
      }

      setUploadProgress(100);

      const db = getDbService();
      const messagesRef = collection(db, 'family_messages');
      await addDoc(messagesRef, {
        text: newMessage.trim() || (attachmentsData.length > 0 ? `Sent ${attachmentsData.length} attachment(s)` : ''),
        senderId: user.uid,
        senderName: user.displayName,
        senderEmail: user.email,
        timestamp: serverTimestamp(),
        type: 'user',
        systemEvent: null,
        attachments: attachmentsData,
        reactions: {},
      });

      setNewMessage('');
      setAttachments([]);
      setUploadProgress(null);
      fileInputRef.current && (fileInputRef.current.value = '');
    } catch (error: any) {
      console.error('Error sending message:', error);
      const errorMsg = error.message || 'Failed to send message. Please try again.';
      setError(errorMsg);
      setUploadProgress(null);
      // Clear error after 5 seconds
      setTimeout(() => setError(null), 5000);
    } finally {
      setSending(false);
    }
  };

  const deleteMessage = async (messageId: string) => {
    const db = getDbService();
    try {
      const messageRef = doc(db, 'family_messages', messageId);
      await deleteDoc(messageRef);
    } catch (error) {
      console.error('Error deleting message:', error);
    }
    setShowActions(null);
  };

  const startEdit = (message: Message) => {
    setEditingMessage(message);
    setEditText(message.text);
    setShowActions(null);
  };

  const saveEdit = async (messageId: string) => {
    if (!editText.trim()) return;
    
    const db = getDbService();
    try {
      const messageRef = doc(db, 'family_messages', messageId);
      await updateDoc(messageRef, {
        text: editText.trim(),
        edited: true,
        editedAt: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error editing message:', error);
    }
    setEditingMessage(null);
    setEditText('');
  };

  const cancelEdit = () => {
    setEditingMessage(null);
    setEditText('');
  };

  const addReaction = async (messageId: string, emoji: string) => {
    const db = getDbService();
    try {
      const messageRef = doc(db, 'family_messages', messageId);
      const message = messages.find(m => m.id === messageId);
      if (!message) return;

      const reactions = message.reactions || {};
      const emojiKey = emoji;
      const userId = user?.uid || '';
      
      // Get current reactions for this emoji
      const currentReactions = (reactions[emojiKey] as string[]) || [];
      
      // Remove reaction if already added
      if (currentReactions.includes(userId)) {
        const updatedReactions = currentReactions.filter((id: string) => id !== userId);
        if (updatedReactions.length === 0) {
          delete reactions[emojiKey];
        } else {
          reactions[emojiKey] = updatedReactions;
        }
      } else {
        // Add reaction
        reactions[emojiKey] = [...currentReactions, userId];
      }

      await updateDoc(messageRef, { reactions });
    } catch (error) {
      console.error('Error adding reaction:', error);
    }
    setShowActions(null);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);
    setShowMobileActions(false);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const formatMessageTime = (date: Date) => {
    return format(date, 'h:mm a');
  };

  // Group messages by date
  const groupedMessages = messages.reduce((groups, message) => {
    const date = format(message.timestamp, 'yyyy-MM-dd');
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {} as Record<string, Message[]>);

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 pb-4">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center space-x-2">
          <MessageCircle className="text-green-500" size={28} />
          <span>Family Chat</span>
        </h1>
        <p className="text-gray-500">Chat with the whole family</p>
      </div>

      {/* Messages Container */}
      <div className="flex-1 bg-white rounded-2xl shadow-sm overflow-hidden flex flex-col">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <MessageCircle size={48} className="mb-4" />
              <p>No messages yet</p>
              <p className="text-sm">Start the conversation!</p>
            </div>
          ) : (
            Object.entries(groupedMessages).map(([date, dateMessages]) => (
              <div key={date}>
                {/* Date Separator */}
                <div className="flex items-center justify-center my-4">
                  <span className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
                    {format(new Date(date), 'MMMM d, yyyy')}
                  </span>
                </div>

                {/* Messages */}
                {dateMessages.map((message) => {
                  const isOwnMessage = message.senderId === user?.uid;
                  const isSystemMessage = message.type === 'system';

                  if (isSystemMessage) {
                    return (
                      <div key={message.id} className="flex justify-center my-2">
                        <span className="text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                          {message.text}
                        </span>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={message.id}
                      className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-4 group`}
                    >
                      <div className="relative group">
                        <div
                          className={`max-w-[85%] rounded-2xl px-5 py-3 ${
                            isOwnMessage
                              ? 'bg-green-100 rounded-br-md'
                              : 'bg-white border border-gray-200 rounded-bl-md'
                          }`}
                        >
                          {!isOwnMessage && (
                            <p className="text-xs font-semibold text-gray-600 mb-1.5">
                              {message.senderName}
                            </p>
                          )}

                          {/* Edit Mode */}
                          {editingMessage?.id === message.id ? (
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                className="flex-1 px-2 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                                autoFocus
                              />
                              <button onClick={() => saveEdit(message.id)} className="text-green-500">
                                <Check size={16} />
                              </button>
                              <button onClick={cancelEdit} className="text-red-500">
                                <X size={16} />
                              </button>
                            </div>
                          ) : (
                            <>
                              {/* Text Content */}
                              {message.text && (
                                <p
                                  className={`text-base leading-relaxed ${
                                    isOwnMessage ? 'text-gray-800' : 'text-gray-700'
                                  }`}
                                >
                                  {message.text}
                                </p>
                              )}

                              {/* Attachments */}
                              {message.attachments && message.attachments.length > 0 && (
                                <div className="mt-3 space-y-2">
                                  {message.attachments.map((attachment) => (
                                    <div key={attachment.id} className="attachment-item">
                                      {attachment.fileType === 'image' ? (
                                        <img 
                                          src={attachment.url} 
                                          alt={attachment.title}
                                          className="max-w-full rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                          onClick={() => window.open(attachment.url, '_blank')}
                                        />
                                      ) : (
                                        <a 
                                          href={attachment.url} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          className="flex items-center gap-2 text-blue-500 hover:underline"
                                        >
                                          <Paperclip size={16} />
                                          <span>{attachment.title}</span>
                                        </a>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Edited indicator */}
                              {message.edited && (
                                <p className="text-[10px] text-gray-400 mt-1.5">
                                  edited
                                </p>
                              )}

                              {/* Reactions display */}
                              {message.reactions && Object.keys(message.reactions).length > 0 && (
                                <div className="flex flex-wrap gap-1.5 mt-3">
                                  {Object.entries(message.reactions).map(([emoji, users]) => (
                                    <button
                                      key={emoji}
                                      onClick={() => addReaction(message.id, emoji)}
                                      className={`text-sm px-2.5 py-1 rounded-full border ${
                                        (users as unknown as string[]).includes(user?.uid || '')
                                          ? 'bg-green-100 border-green-300 text-green-700'
                                          : 'bg-gray-100 border-gray-300 text-gray-700'
                                      }`}
                                    >
                                      <span className="mr-1">{emoji}</span>
                                      <span className="text-xs font-medium">{(users as unknown as string[]).length}</span>
                                    </button>
                                  ))}
                                </div>
                              )}

                              {/* Time and actions */}
                              <div className="flex items-center justify-between mt-2 pt-1 border-t border-black/5">
                                <p
                                  className={`text-[11px] text-gray-400 ${
                                    isOwnMessage ? '' : ''
                                  }`}
                                >
                                  {formatMessageTime(message.timestamp)}
                                </p>

                                {/* Quick reactions */}
                                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200 translate-y-1 group-hover:translate-y-0">
                                  {QUICK_REACTIONS.slice(0, 3).map((emoji) => (
                                    <button
                                      key={emoji}
                                      onClick={() => addReaction(message.id, emoji)}
                                      className="w-7 h-7 flex items-center justify-center text-lg bg-white rounded-full shadow-sm border border-gray-200 hover:scale-110 hover:shadow-md transition-all"
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </>
                          )}
                        </div>

                        {/* Action menu (three dots) - show for own messages OR admin users */}
                        {(isOwnMessage || isAdmin) && !editingMessage && !isSystemMessage && (
                          <button
                            onClick={() => setShowActions(showActions === message.id ? null : message.id)}
                            className="absolute -right-10 top-1 p-1.5 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-all duration-200"
                          >
                            <MoreVertical size={16} />
                          </button>
                        )}

                        {/* Action menu (three dots) - show for own messages OR admin users */}
                        {(isOwnMessage || isAdmin) && !editingMessage && !isSystemMessage && (
                          <button
                            onClick={() => setShowActions(showActions === message.id ? null : message.id)}
                            className="absolute -right-8 top-0 p-1 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <MoreVertical size={16} />
                          </button>
                        )}

                        {/* Actions dropdown */}
                        {showActions === message.id && (
                          <div className="absolute right-0 top-6 bg-white shadow-lg rounded-lg py-1 z-10 min-w-[120px]">
                            {/* Show Edit option only for own messages */}
                            {isOwnMessage && (
                              <button
                                onClick={() => startEdit(message)}
                                className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center gap-2"
                              >
                                <Edit2 size={14} />
                                Edit
                              </button>
                            )}
                            {/* Delete option - for own messages or admin */}
                            <button
                              onClick={() => {
                                // For admin deleting others' messages, show confirmation
                                if (isAdmin && !isOwnMessage) {
                                  if (window.confirm(`Delete message from ${message.senderName}?`)) {
                                    deleteMessage(message.id);
                                  }
                                } else {
                                  deleteMessage(message.id);
                                }
                              }}
                              className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center gap-2 text-red-500"
                            >
                              <Trash2 size={14} />
                              {isAdmin && !isOwnMessage ? 'Admin Delete' : 'Delete'}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Attachment previews */}
        {attachments.length > 0 && (
          <div className="flex-shrink-0 px-4 py-2 bg-gray-50 border-t border-gray-100">
            <div className="flex flex-wrap gap-2">
              {attachments.map((file, index) => (
                <div key={index} className="relative group">
                  {file.type.startsWith('image/') ? (
                    <img
                      src={URL.createObjectURL(file)}
                      alt={file.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                      <Paperclip size={20} />
                    </div>
                  )}
                  <button
                    onClick={() => removeAttachment(index)}
                    className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
            
            {/* Upload Progress Bar */}
            {uploadProgress !== null && (
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                  <span>{sending ? 'Uploading...' : 'Processing...'}</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="flex-shrink-0 px-4 py-3 bg-red-100 border-t border-red-300">
            <div className="flex items-center justify-between">
              <p className="text-red-700 text-sm font-medium flex-1">{error}</p>
              <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 ml-2">
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        {/* Message Input */}
        <form
          onSubmit={sendMessage}
          className="flex-shrink-0 border-t border-gray-100 p-4 bg-gray-50"
        >
          <div className="flex items-center gap-2">
            {/* Mobile actions button */}
            <button
              type="button"
              onClick={() => setShowMobileActions(!showMobileActions)}
              className="lg:hidden p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
            >
              <Plus size={20} />
            </button>

            {/* Mobile attachment buttons */}
            <div className={`${showMobileActions ? 'flex' : 'hidden'} lg:flex items-center gap-2`}>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                multiple
                accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
                title="Attach file"
              >
                <Paperclip size={20} />
              </button>
              
              <input
                type="file"
                ref={cameraInputRef}
                onChange={handleFileSelect}
                accept="image/*"
                capture="environment"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
                title="Take photo"
              >
                <Camera size={20} />
              </button>
            </div>

            {/* Emoji picker toggle */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
              >
                <Smile size={20} />
              </button>

              {/* Emoji picker dropdown */}
              {showEmojiPicker && (
                <div className="absolute bottom-full left-0 mb-2 bg-white shadow-lg rounded-lg p-2 grid grid-cols-6 gap-1 w-48">
                  {['😀', '😂', '🥰', '😮', '😢', '😡', '👍', '👎', '❤️', '🎉', '🎊', '🎁', '🔥', '⭐', '💯', '🙏', '💪', '👋', '🎵', '💡'].map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => {
                        setNewMessage(prev => prev + emoji);
                        setShowEmojiPicker(false);
                      }}
                      className="text-xl p-1 hover:bg-gray-100 rounded"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
            <button
              type="submit"
              disabled={sending || (!newMessage.trim() && attachments.length === 0)}
              className="p-3 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center min-w-[48px]"
            >
              {sending ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
              ) : (
                <span className="text-lg">➤</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FamilyChat;
