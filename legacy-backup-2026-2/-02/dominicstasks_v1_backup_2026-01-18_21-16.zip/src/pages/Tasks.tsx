import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useTasks } from '../context/TasksContext';
import { useAuth } from '../context/AuthContext';
import TaskModal from '../components/TaskModal';
import CommentsModal from '../components/CommentsModal';
import { Task, TaskSection, TaskStatus, MirroredTask } from '../types';
import { Plus, RefreshCw, Archive, RotateCcw, Edit2, Trash2, User, Settings, Trash, AlertTriangle, GripVertical, MessageCircle, MoreHorizontal, X } from 'lucide-react';
import { getDbService, isDevMode } from '../services/firebase';
import { collection, addDoc, serverTimestamp, getDocs, deleteDoc, doc } from 'firebase/firestore';
import { 
  needsCatchUp, 
  isFromYesterday, 
  getMirroredTasksForToday,
  formatSmartDate
} from '../utils';

type TabType = 'tasks' | 'history' | 'deleted' | 'profile';

// Type guard for MirroredTask
const isMirroredTask = (task: Task | MirroredTask): task is MirroredTask => {
  return 'isMirrored' in task && !!(task as MirroredTask).isMirrored;
};

// Check if device supports touch
const isTouchDevice = () => {
  if (typeof window === 'undefined') return false;
  return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
};

const Tasks: React.FC = () => {
  const { tasks, loading, completeTask, uncompleteTask, deleteTask, restoreDeletedTask, reviveTask, moveTask } = useTasks();
  const { user, isParent } = useAuth();
  const [showAddModal, setShowAddModal] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [restoreMessage, setRestoreMessage] = useState<string | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('tasks');
  const [showDeleteWarning, setShowDeleteWarning] = useState(false);
  const [taskToDelete, setTaskToDelete] = useState<Task | null>(null);
  const [draggedTask, setDraggedTask] = useState<Task | null>(null);
  const [dragOverSection, setDragOverSection] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [commentsTask, setCommentsTask] = useState<Task | null>(null);
  const [openMenuTaskId, setOpenMenuTaskId] = useState<string | null>(null);
  
  // Touch drag state
  const touchDragRef = useRef<{
    task: Task | null;
    startY: number;
    startX: number;
    element: HTMLElement | null;
  }>({ task: null, startY: 0, startX: 0, element: null });

  // Check if device is touch-enabled
  useEffect(() => {
    setIsMobile(isTouchDevice());
  }, []);

  // Organize tasks by section - show ALL tasks including completed ones on main page
  // Only hide tasks that are soft-deleted (in trash)
  const allTasks = tasks.filter((t) => !t.deletedAt);
  const todayTasks = allTasks.filter((t) => t.status === 'today' || t.status === 'done');
  const todoTasks = allTasks.filter((t) => t.status === 'todo' || t.status === 'done');

  // Active tasks (not done)
  const morningTasks = todayTasks.filter((t) => t.section === 'morning');
  const afternoonTasks = todayTasks.filter((t) => t.section === 'afternoon');

  // NEW: Catch Up section - tasks that need to be shored up from yesterday or before
  const catchUpTasks = allTasks.filter((t) => 
    t.status !== 'done' && 
    !t.deletedAt &&
    (needsCatchUp(t) || isFromYesterday(t))
  );

  // NEW: Get mirrored tasks from right column sections that have today's date
  const rightColumnTasks = todoTasks.filter((t) => 
    ['assignments', 'leftovers', 'experiments', 'support'].includes(t.section)
  );
  
  const mirroredTasksMorning: MirroredTask[] = getMirroredTasksForToday(rightColumnTasks).map(task => ({
    ...task,
    isMirrored: true,
    originalSection: task.section
  }));

  const assignmentsTasks = todoTasks.filter((t) => t.section === 'assignments');
  const leftoversTasks = todoTasks.filter((t) => t.section === 'leftovers');
  const experimentsTasks = todoTasks.filter((t) => t.section === 'experiments');
  const supportTasks = todoTasks.filter((t) => t.section === 'support');

  // History tasks (archived)
  const historyTasks = tasks.filter((t) => t.archivedAt && !t.deletedAt);

  // Deleted tasks
  const deletedTasks = tasks.filter((t) => t.deletedAt);

  // Desktop drag and drop handlers
  const handleDragStart = useCallback((task: Task) => {
    setDraggedTask(task);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent, section: string) => {
    e.preventDefault();
    setDragOverSection(section);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverSection(null);
  }, []);

  const handleDrop = useCallback(async (e: React.DragEvent, targetSection: TaskSection) => {
    e.preventDefault();
    setDragOverSection(null);
    
    if (!draggedTask || draggedTask.section === targetSection) {
      setDraggedTask(null);
      return;
    }

    // Determine the new status based on the target section
    let newStatus: TaskStatus = 'todo';
    if (['morning', 'afternoon'].includes(targetSection)) {
      newStatus = 'today';
    } else if (targetSection === 'catchup') {
      newStatus = 'today';
    }

    try {
      await moveTask(draggedTask.id, targetSection, newStatus);
    } catch (error) {
      console.error('Error moving task:', error);
    } finally {
      setDraggedTask(null);
    }
  }, [draggedTask, moveTask]);

  const handleDragEnd = useCallback(() => {
    setDraggedTask(null);
    setDragOverSection(null);
  }, []);

  // Mobile touch drag handlers
  const handleTouchStart = useCallback((e: React.TouchEvent, task: Task) => {
    if (!isMobile) return;
    
    const touch = e.touches[0];
    touchDragRef.current = {
      task,
      startY: touch.clientY,
      startX: touch.clientX,
      element: e.currentTarget as HTMLElement
    };
    
    setDraggedTask(task);
    
    // Add visual feedback
    e.currentTarget.classList.add('dragging');
  }, [isMobile]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isMobile || !touchDragRef.current.task) return;
    
    const touch = e.touches[0];
    
    // Find the element under the touch point
    const elementUnderTouch = document.elementFromPoint(touch.clientX, touch.clientY);
    
    // Find the closest task-section parent
    const sectionElement = elementUnderTouch?.closest('.task-section');
    
    if (sectionElement) {
      const sectionId = sectionElement.getAttribute('data-section-id') || 
                        sectionElement.querySelector('[data-section-id]')?.getAttribute('data-section-id');
      
      if (sectionId && sectionId !== touchDragRef.current.task.section) {
        setDragOverSection(sectionId);
      } else {
        setDragOverSection(null);
      }
    } else {
      setDragOverSection(null);
    }
  }, [isMobile]);

  const handleTouchEnd = useCallback(async () => {
    if (!isMobile || !touchDragRef.current.task || !dragOverSection) {
      // Clean up
      if (touchDragRef.current.element) {
        touchDragRef.current.element.classList.remove('dragging');
      }
      setDraggedTask(null);
      setDragOverSection(null);
      touchDragRef.current = { task: null, startY: 0, startX: 0, element: null };
      return;
    }

    const targetSection = dragOverSection as TaskSection;
    const task = touchDragRef.current.task;

    if (task.section !== targetSection) {
      // Determine the new status based on the target section
      let newStatus: TaskStatus = 'todo';
      if (['morning', 'afternoon'].includes(targetSection)) {
        newStatus = 'today';
      } else if (targetSection === 'catchup') {
        newStatus = 'today';
      }

      try {
        await moveTask(task.id, targetSection, newStatus);
      } catch (error) {
        console.error('Error moving task:', error);
      }
    }

    // Clean up
    if (touchDragRef.current.element) {
      touchDragRef.current.element.classList.remove('dragging');
    }
    setDraggedTask(null);
    setDragOverSection(null);
    touchDragRef.current = { task: null, startY: 0, startX: 0, element: null };
  }, [isMobile, dragOverSection, moveTask]);

  // Tasks to restore
  const tasksToRestore = {
    morning: [
      { title: 'CS test', section: 'morning', status: 'today', priority: 'high', description: 'ASAP Important', taskType: 'exam' },
      { title: 'CS lesson', section: 'morning', status: 'today', priority: 'high', description: 'After test', taskType: 'regular' },
      { title: 'Foundations prep', section: 'morning', status: 'today', priority: 'medium', description: 'This morning', taskType: 'regular' },
      { title: 'Maths prep', section: 'morning', status: 'today', priority: 'medium', description: 'This morning', taskType: 'regular' },
    ],
    afternoon: [
      { title: 'CS tutorials', section: 'afternoon', status: 'today', priority: 'high', description: '3:00 PM', taskType: 'regular' },
      { title: 'Tutorial prep', section: 'afternoon', status: 'today', priority: 'high', description: 'Afternoon', taskType: 'regular' },
      { title: 'Printing', section: 'afternoon', status: 'today', priority: 'medium', description: 'Sort out printing - check if Daddy fixed home printer, or have things ready to print in office', taskType: 'regular' },
    ],
    assignments: [
      { title: 'Math assignment', section: 'assignments', status: 'todo', priority: 'high', description: 'Friday 16th Important', taskType: 'assignment', deadlineDate: new Date('2025-01-17') },
      { title: 'Science assignment', section: 'assignments', status: 'todo', priority: 'high', description: 'Friday 16th (due 20th) Important', taskType: 'assignment', deadlineDate: new Date('2025-01-20') },
    ],
    leftovers: [
      { title: 'Notes on Foundations lesson 13', section: 'leftovers', status: 'todo', priority: 'low', description: 'When you have time', taskType: 'personal' },
      { title: 'Highlight Science book pages 114-121', section: 'leftovers', status: 'todo', priority: 'low', description: 'When you have time', taskType: 'personal' },
      { title: 'Science vocab', section: 'leftovers', status: 'todo', priority: 'low', description: 'When you have time', taskType: 'personal' },
    ],
    experiments: [
      { title: 'Write up Melting experiment', section: 'experiments', status: 'todo', priority: 'medium', description: 'This week', taskType: 'project' },
      { title: 'Write up Lava lamp experiment', section: 'experiments', status: 'todo', priority: 'medium', description: 'This week', taskType: 'project' },
    ],
    support: [
      { title: 'Printer working?', section: 'support', status: 'todo', priority: 'high', description: 'By lunchtime - Let Brenda know at lunchtime if not', taskType: 'personal' },
      { title: '30-minute check-ins with Brenda', section: 'support', status: 'todo', priority: 'high', description: 'Every 30 mins Support', taskType: 'personal' },
      { title: 'Organise squash exercise session', section: 'support', status: 'todo', priority: 'low', description: 'This week Fun!', taskType: 'personal' },
    ],
  };

  const restoreTasks = async () => {
    if (!confirm('This will restore all 17 tasks. Continue?')) return;
    
    setRestoring(true);
    setRestoreMessage(null);

    try {
      // Skip in dev mode
      if (isDevMode()) {
        setRestoreMessage('Restoration disabled in dev mode');
        setRestoring(false);
        return;
      }

      let totalAdded = 0;

      // Clear existing tasks first
      const db = getDbService();
      const snapshot = await getDocs(collection(db, 'tasks'));
      for (const docSnapshot of snapshot.docs) {
        await deleteDoc(doc(db, 'tasks', docSnapshot.id));
      }

      // Add tasks for each category
      for (const [, taskList] of Object.entries(tasksToRestore)) {
        for (const task of taskList as Array<{ title: string; section: string; status: string; priority: string; description: string; taskType: string; deadlineDate?: Date }>) {
          await addDoc(collection(db, 'tasks'), {
            title: task.title,
            section: task.section,
            status: task.status,
            priority: task.priority,
            description: task.description,
            taskType: task.taskType,
            tags: [],
            createdBy: 'dominicgiles691@gmail.com',
            createdAt: serverTimestamp(),
            order: totalAdded,
            dueDate: task.deadlineDate || null,
            deadlineDate: task.deadlineDate ? serverTimestamp() : null,
          });
          totalAdded++;
        }
      }

      setRestoreMessage(`Successfully restored ${totalAdded} tasks!`);
    } catch (error) {
      console.error('Error restoring tasks:', error);
      setRestoreMessage('Failed to restore tasks. Please try again.');
    } finally {
      setRestoring(false);
    }
  };

  const formatDate = () => {
    const now = new Date();
    const options: Intl.DateTimeFormatOptions = { weekday: 'long', day: 'numeric', month: 'long' };
    return now.toLocaleDateString('en-US', options);
  };

  const formatDateTime = (date?: Date) => {
    if (!date) return '';
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      day: 'numeric', 
      month: 'short',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'Important';
      case 'medium': return 'Support';
      case 'low': return 'Left over';
      default: return '';
    }
  };

  const getPriorityClass = (priority: string) => {
    switch (priority) {
      case 'high': return 'priority-high';
      case 'medium': return 'priority-medium';
      case 'low': return 'priority-low';
      default: return 'priority-normal';
    }
  };

  const handleCheckboxClick = async (e: React.MouseEvent, task: Task) => {
    e.stopPropagation();
    // Only toggle completion status when checkbox is clicked
    if (task.status === 'done') {
      // Uncheck - restore to active
      await uncompleteTask(task.id);
    } else {
      // Check - mark as done
      await completeTask(task.id);
    }
  };





  const confirmDeleteTask = async () => {
    if (taskToDelete) {
      await deleteTask(taskToDelete.id);
      setTaskToDelete(null);
    }
    setShowDeleteWarning(false);
  };

  const TaskListSection: React.FC<{ 
    title: string; 
    subtitle?: string; 
    icon: React.ReactNode; 
    iconClass: string; 
    tasks: (Task | MirroredTask)[];
    sectionId?: string;
    onDragOver?: (e: React.DragEvent) => void;
    onDragLeave?: () => void;
    onDrop?: (e: React.DragEvent) => void;
    isDropTarget?: boolean;
    showWhenEmpty?: boolean;
  }> = ({ title, subtitle, icon, iconClass, tasks, sectionId, onDragOver, onDragLeave, onDrop, isDropTarget, showWhenEmpty = false }) => {
    // Don't render anything if no tasks and not forcing show
    if (tasks.length === 0 && !showWhenEmpty) return null;

    return (
      <div 
        className={`task-section ${isDropTarget ? 'drop-target' : ''} ${tasks.length === 0 ? 'empty-section' : ''}`}
        data-section-id={sectionId}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
      >
        <div className="section-header">
          <div className={`section-icon ${iconClass}`}>
            {icon}
          </div>
          <span className="section-title">{title}</span>
          {subtitle && <span className="section-subtitle">{subtitle}</span>}
        </div>
        {tasks.length > 0 ? (
          <div>
            {tasks.map((task) => (
              <div 
                key={task.id} 
                className={`task-item ${task.status === 'done' ? 'completed' : ''} ${isMirroredTask(task) ? 'mirrored-task' : ''}`}
                data-task-id={task.id}
                draggable={!isMobile}
                onDragStart={!isMobile ? (e) => {
                  e.preventDefault(); // Prevent text selection
                  e.dataTransfer.setData('taskId', task.id);
                  e.dataTransfer.effectAllowed = 'move';
                  handleDragStart(task);
                } : undefined}
                onDragEnd={!isMobile ? handleDragEnd : undefined}
                onTouchStart={(e) => isMobile ? handleTouchStart(e, task as Task) : undefined}
                onTouchMove={isMobile ? handleTouchMove : undefined}
                onTouchEnd={isMobile ? handleTouchEnd : undefined}
              >
                <div 
                  className="drag-handle"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!isMobile) {
                      setEditingTask(task);
                    }
                  }}
                  onTouchStart={(e) => isMobile ? handleTouchStart(e, task as Task) : undefined}
                  onTouchMove={isMobile ? handleTouchMove : undefined}
                  onTouchEnd={isMobile ? handleTouchEnd : undefined}
                  title={isMobile ? "Drag to move" : "Click to edit"}
                >
                  <GripVertical size={16} />
                </div>
                <div 
                  className="task-checkbox"
                  onClick={(e) => handleCheckboxClick(e, task)}
                ></div>
                <div 
                  className="task-content"
                  onClick={() => setEditingTask(task)}
                >
                  <div className="task-text">
                    {task.title}
                    {isMirroredTask(task) && (
                      <span className="mirrored-badge" title={`Also in ${task.originalSection}`}>
                        ↔ {task.originalSection}
                      </span>
                    )}
                  </div>
                  {task.description && (
                    <span className="task-time">{task.description.split(' ')[0]}</span>
                  )}
                  {/* NEW: Show date badge for tasks with dates */}
                  {(task.dueDate || task.deadlineDate) && (
                    <span className="task-date-badge">
                      {formatSmartDate(task.dueDate || task.deadlineDate)}
                    </span>
                  )}
                  {task.priority && task.priority !== 'medium' && (
                    <span className={`task-priority ${getPriorityClass(task.priority)}`}>
                      {getPriorityLabel(task.priority)}
                    </span>
                  )}
                  {task.status === 'done' && (
                    <button
                      className="restore-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        uncompleteTask(task.id);
                      }}
                      title="Click to restore this task"
                    >
                      <RotateCcw size={12} />
                      Restore
                    </button>
                  )}
                </div>
                <div className="task-actions">
                  {/* Comment button */}
                  <button
                    className="action-btn comment"
                    onClick={(e) => {
                      e.stopPropagation();
                      setCommentsTask(task);
                    }}
                    title="View comments"
                  >
                    <MessageCircle size={14} />
                  </button>
                  {/* Edit button */}
                  <button
                    className="action-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditingTask(task);
                    }}
                    title="Edit this task"
                  >
                    <Edit2 size={14} />
                  </button>
                  {/* Menu button (hidden delete) */}
                  <div className="relative">
                    <button
                      className="action-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        setOpenMenuTaskId(openMenuTaskId === task.id ? null : task.id);
                      }}
                      title="More options"
                    >
                      <MoreHorizontal size={14} />
                    </button>
                    {/* Dropdown menu */}
                    {openMenuTaskId === task.id && (
                      <div className="absolute right-0 top-full mt-1 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50 min-w-[120px]">
                        <button
                          className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                          onClick={(e) => {
                            e.stopPropagation();
                            setTaskToDelete(task);
                            setShowDeleteWarning(true);
                            setOpenMenuTaskId(null);
                          }}
                        >
                          <Trash2 size={12} />
                          Delete
                        </button>
                      </div>
                    )}
                  </div>
                </div>
                {/* Close menu when clicking outside */}
                {openMenuTaskId === task.id && (
                  <div
                    className="fixed inset-0 z-40"
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenMenuTaskId(null);
                    }}
                  />
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="empty-section-message">
            <span className="empty-icon">✨</span>
            <span>All caught up!</span>
          </div>
        )}
      </div>
    );
  };

  const HistorySection: React.FC<{ tasks: Task[], title: string }> = ({ tasks, title }) => {
    if (tasks.length === 0) {
      return (
        <div className="history-section">
          <div className="history-title">
            <RotateCcw size={18} />
            <span>{title}</span>
          </div>
          <div className="history-empty">
            No tasks in history yet. Complete some tasks to see them here!
          </div>
        </div>
      );
    }

    return (
      <div className="history-section">
        <div className="history-title">
          <RotateCcw size={18} />
          <span>{title}</span>
        </div>
        {tasks.map((task) => (
          <div key={task.id} className="history-item">
            <div className="task-checkbox" style={{ background: '#cbd5e0', borderColor: '#cbd5e0' }}></div>
            <div className="history-item-content">
              <div className="history-item-title">{task.title}</div>
              <div className="history-item-date">
                Completed: {formatDateTime(task.completedAt ?? undefined)}
              </div>
            </div>
            <button
              className="history-btn"
              onClick={() => reviveTask(task.id)}
              title="Restore this task to active list"
            >
              <RotateCcw size={14} />
              <span>Restore</span>
            </button>
          </div>
        ))}
      </div>
    );
  };

  const DeletedSection: React.FC<{ tasks: Task[] }> = ({ tasks }) => {
    if (tasks.length === 0) {
      return (
        <div className="deleted-section">
          <div className="deleted-title">
            <Trash size={18} />
            <span>Deleted Tasks (Recover within 30 days)</span>
          </div>
          <div className="history-empty">
            No deleted tasks. When you delete tasks, they'll appear here for 30 days.
          </div>
        </div>
      );
    }

    return (
      <div className="deleted-section">
        <div className="deleted-title">
          <Trash size={18} />
          <span>Deleted Tasks (Recover within 30 days)</span>
        </div>
        {tasks.map((task) => (
          <div key={task.id} className="deleted-item">
            <div className="task-checkbox" style={{ background: '#fed7d7', borderColor: '#feb2b2' }}></div>
            <div className="deleted-item-content">
              <div className="deleted-item-title">{task.title}</div>
              <div className="deleted-item-date">
                Deleted: {formatDateTime(task.deletedAt ?? undefined)}
              </div>
            </div>
            <button
              className="history-btn"
              onClick={() => restoreDeletedTask(task.id)}
              title="Restore this task"
            >
              <RotateCcw size={14} />
              <span>Restore</span>
            </button>
          </div>
        ))}
      </div>
    );
  };

  const ProfileSection: React.FC = () => {
    const activeTasksCount = tasks.filter(t => t.status !== 'done' && !t.archivedAt && !t.deletedAt).length;
    const completedTasksCount = tasks.filter(t => t.status === 'done' && !t.archivedAt && !t.deletedAt).length;
    const historyCount = tasks.filter(t => t.archivedAt && !t.deletedAt).length;
    const deletedCount = tasks.filter(t => t.deletedAt).length;

    const userInitials = user?.displayName?.split(' ').map(n => n[0]).join('').toUpperCase() || user?.email?.[0].toUpperCase() || 'U';

    return (
      <div className="profile-section">
        <div className="profile-header">
          <div className="profile-avatar">{userInitials}</div>
          <div className="profile-info">
            <h3>{user?.displayName || 'User'}</h3>
            <p>{user?.email}</p>
            {isParent && <span className="profile-badge">Parent / Admin</span>}
          </div>
        </div>

        <div className="profile-stats">
          <div className="profile-stat">
            <div className="profile-stat-value">{activeTasksCount}</div>
            <div className="profile-stat-label">Active Tasks</div>
          </div>
          <div className="profile-stat">
            <div className="profile-stat-value">{completedTasksCount}</div>
            <div className="profile-stat-label">Completed</div>
          </div>
          <div className="profile-stat">
            <div className="profile-stat-value">{historyCount + deletedCount}</div>
            <div className="profile-stat-label">Archived</div>
          </div>
        </div>

        {isParent && (
          <div className="admin-section" style={{ marginTop: 20 }}>
            <div className="admin-title">
              <Settings size={20} />
              <span>Admin Controls</span>
            </div>
            <div className="admin-actions">
              <button
                onClick={restoreTasks}
                disabled={restoring}
                className="admin-btn primary"
              >
                <RefreshCw size={18} className={restoring ? 'animate-spin' : ''} />
                <span>{restoring ? 'Restoring...' : 'Restore Default Tasks'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const getSectionIcon = (section: string) => {
    switch (section) {
      case 'morning':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
        );
      case 'afternoon':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 16v-4"></path>
            <path d="M12 8h.01"></path>
          </svg>
        );
      case 'assignments':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
            <line x1="16" y1="13" x2="8" y2="13"></line>
            <line x1="16" y1="17" x2="8" y2="17"></line>
          </svg>
        );
      case 'leftovers':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
          </svg>
        );
      case 'experiments':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
            <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
          </svg>
        );
      case 'support':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        );
      case 'catchup':
        return (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
            <circle cx="8.5" cy="7" r="4"></circle>
            <polyline points="17 11 19 13 23 9"></polyline>
          </svg>
        );
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const activeTasksCount = tasks.filter(t => t.status !== 'done' && !t.archivedAt && !t.deletedAt).length;
  const completedTasksCount = tasks.filter(t => t.status === 'done' && !t.archivedAt && !t.deletedAt).length;
  const totalTasks = activeTasksCount + completedTasksCount;
  const progressPercentage = totalTasks > 0 ? (completedTasksCount / totalTasks) * 100 : 0;

  return (
    <div className="max-w-[1100px] mx-auto px-5 py-10">
      {/* Restore Message */}
      {restoreMessage && (
        <div className={`restore-message ${
          restoreMessage.includes('Successfully') 
            ? 'restore-message-success' 
            : 'restore-message-error'
        }`}>
          {restoreMessage}
        </div>
      )}

      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-[2.2rem] font-bold text-[#2d3748] mb-2">Dominic's Tasks</h1>
        <p className="text-[#718096] text-base">Take it one step at a time!</p>
        <div className="date-badge">{formatDate()}</div>
      </div>

      {/* Navigation Tabs */}
      <div className="nav-tabs">
        <button
          className={`nav-tab ${activeTab === 'tasks' ? 'active' : ''}`}
          onClick={() => setActiveTab('tasks')}
        >
          <Plus size={18} />
          <span>Tasks</span>
        </button>
        <button
          className={`nav-tab ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          <Archive size={18} />
          <span>History</span>
        </button>
        <button
          className={`nav-tab ${activeTab === 'deleted' ? 'active' : ''}`}
          onClick={() => setActiveTab('deleted')}
        >
          <Trash size={18} />
          <span>Trash</span>
          {deletedTasks.length > 0 && (
            <span style={{ 
              background: '#e53e3e', 
              color: 'white', 
              padding: '2px 8px', 
              borderRadius: 10, 
              fontSize: '0.75rem' 
            }}>
              {deletedTasks.length}
            </span>
          )}
        </button>
        <button
          className={`nav-tab ${activeTab === 'profile' ? 'active' : ''}`}
          onClick={() => setActiveTab('profile')}
        >
          <User size={18} />
          <span>Profile</span>
        </button>
      </div>

      {/* Tasks Tab */}
      {activeTab === 'tasks' && (
        <>
          {/* Floating Add Task Button */}
          <button
            onClick={() => setShowAddModal(true)}
            className="floating-add-btn"
            title="Add New Task"
          >
            <Plus size={28} />
          </button>

          {/* Restore All Tasks Button (if there are archived tasks) */}
          {historyTasks.length > 0 && (
            <div style={{ 
              background: '#fef3c7', 
              border: '2px dashed #d97706',
              borderRadius: '12px',
              padding: '16px',
              marginBottom: '16px',
              textAlign: 'center'
            }}>
              <p style={{ color: '#92400e', marginBottom: '12px', fontWeight: '500' }}>
                {historyTasks.length} task{historyTasks.length !== 1 ? 's' : ''} in History
              </p>
              <button
                onClick={() => {
                  // Restore all archived tasks
                  historyTasks.forEach(task => reviveTask(task.id));
                }}
                style={{
                  background: '#d97706',
                  color: 'white',
                  border: 'none',
                  padding: '10px 20px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  fontWeight: '500',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <RotateCcw size={16} />
                Restore All to Main Page
              </button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-center gap-4 mb-8">
            {isParent && (
              <button
                onClick={restoreTasks}
                disabled={restoring}
                className="flex items-center gap-2 bg-gray-100 text-gray-700 px-4 py-3 rounded-xl font-medium hover:bg-gray-200 transition-colors border border-gray-200"
              >
                <RefreshCw size={18} className={restoring ? 'animate-spin' : ''} />
                <span>{restoring ? 'Restoring...' : 'Restore Tasks'}</span>
              </button>
            )}
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center justify-center gap-2 bg-blue-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-blue-600 transition-colors shadow-lg shadow-blue-500/30"
            >
              <Plus size={20} />
              <span>Add Task</span>
            </button>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Today's Focus - Left Column */}
            <div>
              <h2 className="column-header column-header-amber">Today's Focus</h2>
              
              <TaskListSection
                title="This Morning"
                subtitle="Priority Focus"
                icon={getSectionIcon('morning')}
                iconClass="section-icon-morning"
                tasks={morningTasks}
                sectionId="morning"
                onDragOver={(e) => handleDragOver(e, 'morning')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'morning')}
                isDropTarget={dragOverSection === 'morning'}
                showWhenEmpty={true}
              />
              
              <TaskListSection
                title="This Afternoon"
                subtitle="Keep going!"
                icon={getSectionIcon('afternoon')}
                iconClass="section-icon-afternoon"
                tasks={afternoonTasks}
                sectionId="afternoon"
                onDragOver={(e) => handleDragOver(e, 'afternoon')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'afternoon')}
                isDropTarget={dragOverSection === 'afternoon'}
                showWhenEmpty={true}
              />
              
              {/* NEW: Catch Up Section */}
              <TaskListSection
                title="Catch Up"
                subtitle="From yesterday & before"
                icon={<AlertTriangle size={20} />}
                iconClass="section-icon-catchup"
                tasks={catchUpTasks}
                sectionId="catchup"
                onDragOver={(e) => handleDragOver(e, 'catchup')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'catchup')}
                isDropTarget={dragOverSection === 'catchup'}
                showWhenEmpty={true}
              />

              {/* NEW: Show mirrored tasks from right column that have today's date */}
              {mirroredTasksMorning.length > 0 && (
                <div className="mirrored-section">
                  <div className="mirrored-header">
                    <span className="mirrored-title">Also Today</span>
                    <span className="mirrored-subtitle">From other sections</span>
                  </div>
                  <TaskListSection
                    title="Today's Assignments & Tasks"
                    subtitle="Due today - also in focus"
                    icon={<RotateCcw size={18} />}
                    iconClass="section-icon-mirrored"
                    tasks={mirroredTasksMorning}
                    sectionId="mirrored"
                    onDragOver={(e) => handleDragOver(e, 'morning')}
                    onDragLeave={handleDragLeave}
                    onDrop={(e) => handleDrop(e, 'morning')}
                    isDropTarget={dragOverSection === 'morning'}
                  />
                </div>
              )}
            </div>

            {/* Other Activities - Right Column */}
            <div>
              <h2 className="column-header column-header-purple">Other Activities</h2>
              
              <TaskListSection
                title="Assignments Due"
                subtitle="Don't forget!"
                icon={getSectionIcon('assignments')}
                iconClass="section-icon-assignments"
                tasks={assignmentsTasks}
                sectionId="assignments"
                onDragOver={(e) => handleDragOver(e, 'assignments')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'assignments')}
                isDropTarget={dragOverSection === 'assignments'}
              />
              
              <TaskListSection
                title="Left Over from Last Term"
                subtitle="Finish these up!"
                icon={getSectionIcon('leftovers')}
                iconClass="section-icon-leftovers"
                tasks={leftoversTasks}
                sectionId="leftovers"
                onDragOver={(e) => handleDragOver(e, 'leftovers')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'leftovers')}
                isDropTarget={dragOverSection === 'leftovers'}
              />
              
              <TaskListSection
                title="Experiments"
                subtitle="Write these up!"
                icon={getSectionIcon('experiments')}
                iconClass="section-icon-experiments"
                tasks={experimentsTasks}
                sectionId="experiments"
                onDragOver={(e) => handleDragOver(e, 'experiments')}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'experiments')}
                isDropTarget={dragOverSection === 'experiments'}
              />
              
              <TaskListSection
                title="Support & Activities"
                subtitle="Stay motivated"
                icon={getSectionIcon('support')}
                iconClass="section-icon-support"
                tasks={supportTasks}
              />
            </div>
          </div>

          {/* Progress Section */}
          <div className="progress-section">
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <div className="progress-text">
              {completedTasksCount} of {totalTasks} tasks completed
            </div>
          </div>
        </>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <HistorySection tasks={historyTasks} title="History - Click Restore to bring tasks back" />
      )}

      {/* Deleted Tab */}
      {activeTab === 'deleted' && (
        <DeletedSection tasks={deletedTasks} />
      )}

      {/* Profile Tab */}
      {activeTab === 'profile' && (
        <ProfileSection />
      )}

      {/* Motivation Banner */}
      <div className="motivation-banner">
        <p>"Eating the elephant one step at a time!" - Brenda</p>
      </div>

      {/* Footer */}
      <div className="text-center mt-8 text-[#a0aec0] text-sm">
        You've got this, Dominic!
      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <TaskModal onClose={() => setShowAddModal(false)} />
      )}

      {/* Edit Task Modal */}
      {editingTask && (
        <TaskModal 
          onClose={() => setEditingTask(null)} 
          taskToEdit={editingTask}
        />
      )}

      {/* Delete Warning Modal */}
      {showDeleteWarning && (
        <div className="modal-overlay" onClick={() => setShowDeleteWarning(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3 className="modal-title">
                <AlertTriangle size={20} style={{ color: '#e53e3e', marginRight: 8 }} />
                Delete Task?
              </h3>
              <button className="modal-close" onClick={() => setShowDeleteWarning(false)}>
                ×
              </button>
            </div>
            <div className="modal-body">
              <p style={{ color: '#4a5568', lineHeight: 1.6 }}>
                Are you sure you want to delete <strong>"{taskToDelete?.title}"</strong>?
              </p>
              <p style={{ color: '#718096', marginTop: 12, fontSize: '0.9rem' }}>
                The task will be moved to Trash where it can be recovered for 30 days.
              </p>
            </div>
            <div className="modal-footer">
              <button className="modal-btn cancel" onClick={() => setShowDeleteWarning(false)}>
                Cancel
              </button>
              <button className="modal-btn confirm" onClick={confirmDeleteTask}>
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comments Modal */}
      {commentsTask && (
        <CommentsModal
          task={commentsTask}
          isOpen={!!commentsTask}
          onClose={() => setCommentsTask(null)}
        />
      )}
    </div>
  );
};

export default Tasks;
