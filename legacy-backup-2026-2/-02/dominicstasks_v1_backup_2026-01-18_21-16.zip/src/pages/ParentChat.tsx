import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, 
  limit, doc, updateDoc, deleteDoc 
} from 'firebase/firestore';
import { getDbService, isDevMode, uploadChatAttachment } from '../services/firebase';
import { PrivateMessage, Attachment } from '../types';
import { format } from 'date-fns';
import { 
  Paperclip, Smile, MessageCircle, 
  MoreVertical, Edit2, Trash2, Check, X,
  Camera, Plus, Cloud
} from 'lucide-react';
import { QUICK_REACTIONS } from '../types';
import { loadGoogleApis, requestDriveAccess, getDriveFileContent, isGoogleWorkspaceFile, exportWorkspaceFile, formatFileSize, getFileTypeIcon, getFileCategory } from '../services/googleDrive';

// Simple collection name like FamilyChat
const PARENT_MESSAGES_COLLECTION = 'parent_messages';

const ParentChat: React.FC = () => {
  console.log('[ParentChat] Rendering component');
  const { user } = useAuth();
  console.log('[ParentChat] User:', user?.email, 'isParent:', user?.role === 'parent');
  const [messages, setMessages] = useState<PrivateMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showActions, setShowActions] = useState<string | null>(null);
  const [editingMessage, setEditingMessage] = useState<PrivateMessage | null>(null);
  const [editText, setEditText] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [showMobileActions, setShowMobileActions] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [driveFiles, setDriveFiles] = useState<File[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load Google APIs on mount
  useEffect(() => {
    loadGoogleApis().catch(err => {
      console.log('[ParentChat] Google APIs not available:', err.message);
    });
  }, []);
  useEffect(() => {
    // Skip Firestore connection in dev mode
    if (isDevMode()) {
      console.log('🔧 DEV MODE: Skipping parent messages loading');
      return;
    }

    const db = getDbService();
    // Use simple query like FamilyChat - no where filter needed since this is the only parent chat
    const messagesRef = collection(db, 'parent_messages');
    const q = query(messagesRef, orderBy('timestamp', 'asc'), limit(100));

    console.log('[ParentChat] Setting up Firestore listener for parent_messages collection');

    const unsubscribe = onSnapshot(q, 
      (snapshot) => {
        console.log('[ParentChat] Firestore snapshot received, docs:', snapshot.docs.length);
        if (!snapshot.empty) {
          console.log('[ParentChat] First doc ID:', snapshot.docs[0].id);
        }
        const messagesData: PrivateMessage[] = snapshot.docs.map((doc) => {
          const data = doc.data();
          console.log('[ParentChat] Message:', doc.id, 'text:', data.text?.substring(0, 30));
          return {
            ...data,
            id: doc.id,
            timestamp: data.timestamp?.toDate() || new Date(),
          } as PrivateMessage;
        });
        setMessages(messagesData);
        console.log('[ParentChat] Total messages loaded:', messagesData.length);
      },
      (error) => {
        console.error('[ParentChat] Firestore listener ERROR:', error);
        if (error.code === 'failed-precondition') {
          console.error('[ParentChat] Missing index - but using simple query so this should not happen');
        }
        setError(`Failed to load messages: ${error.message}`);
      }
    );

    return () => unsubscribe();
  }, []);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e?: React.FormEvent) => {
    console.log('[ParentChat] sendMessage called, user:', user?.email, 'message:', newMessage);
    
    if (e) e.preventDefault();

    // Debug logging for the condition
    console.log('[ParentChat] sendMessage check - hasMessage:', !!newMessage.trim(), 'hasAttachments:', attachments.length > 0, 'hasUser:', !!user);
    
    if (!user) {
      console.error('[ParentChat] ERROR: No user authenticated!');
      setError('You are not logged in. Please refresh and log in again.');
      return;
    }
    
    if (!newMessage.trim() && attachments.length === 0) {
      console.log('[ParentChat] Empty message, not sending');
      return;
    }

    console.log('[ParentChat] Sending message...');
    setSending(true);
    setUploadProgress(0);

    try {
      const messageId = `${Date.now()}-${user.uid}`;
      const attachmentsData: Attachment[] = [];

      // Upload attachments with progress tracking
      const totalFiles = attachments.length;
      for (let i = 0; i < attachments.length; i++) {
        const file = attachments[i];
        
        const uploaded = await uploadChatAttachment(file, 'parent', messageId, (progress) => {
          // Calculate overall progress
          const fileProgress = progress / totalFiles;
          const baseProgress = (i / totalFiles) * 100;
          setUploadProgress(baseProgress + fileProgress);
        });
        
        attachmentsData.push({
          id: `${Date.now()}-${Math.random()}`,
          title: file.name,
          url: uploaded.url,
          fileType: uploaded.fileType as 'image' | 'video' | 'document' | 'audio',
        });
      }

      setUploadProgress(100);

      console.log('[ParentChat] Saving message to Firestore...');
      const db = getDbService();
      const messagesRef = collection(db, 'parent_messages');
      
      console.log('[ParentChat] Message data:', {
        text: newMessage.trim() || (attachmentsData.length > 0 ? `Sent ${attachmentsData.length} attachment(s)` : ''),
        senderId: user.uid,
        senderName: user.displayName,
        senderEmail: user.email,
      });
      
      await addDoc(messagesRef, {
        text: newMessage.trim() || (attachmentsData.length > 0 ? `Sent ${attachmentsData.length} attachment(s)` : ''),
        senderId: user.uid,
        senderName: user.displayName,
        senderEmail: user.email,
        timestamp: serverTimestamp(),
        readBy: [user.uid],
        attachments: attachmentsData,
        reactions: {},
      });

      console.log('[ParentChat] Message saved successfully!');
      console.log('[ParentChat] Current messages count:', messages.length);
      
      setNewMessage('');
      setAttachments([]);
      setUploadProgress(null);
      fileInputRef.current && (fileInputRef.current.value = '');
      
      // Verify message appeared after a short delay
      setTimeout(() => {
        console.log('[ParentChat] Verification - messages count after send:', messages.length);
        const sentMessage = messages.find(m => 
          m.text?.toLowerCase().includes(newMessage.trim().toLowerCase().substring(0, 10))
        );
        if (!sentMessage) {
          console.warn('[ParentChat] WARNING: Message not found in messages array after sending!');
          setError('Message may not have been saved. Please check your connection and try again.');
        }
      }, 2000);
    } catch (error: any) {
      console.error('[ParentChat] ERROR sending message:', error);
      console.error('[ParentChat] Error code:', error?.code);
      console.error('[ParentChat] Error message:', error?.message);
      
      const errorMsg = error?.code === 'permission-denied' 
        ? 'Permission denied. Please refresh and try again.'
        : error instanceof Error ? error.message : 'Failed to send message. Please try again.';
      
      setError(errorMsg);
      setUploadProgress(null);
      // Clear error after 5 seconds
      setTimeout(() => setError(null), 5000);
    } finally {
      console.log('[ParentChat] Send complete, setting sending=false');
      setSending(false);
    }
  };

  const deleteMessage = async (messageId: string) => {
    const db = getDbService();
    try {
      const messageRef = doc(db, PARENT_MESSAGES_COLLECTION, messageId);
      await deleteDoc(messageRef);
    } catch (error) {
      console.error('Error deleting message:', error);
    }
    setShowActions(null);
  };

  const startEdit = (message: PrivateMessage) => {
    setEditingMessage(message);
    setEditText(message.text);
    setShowActions(null);
  };

  const saveEdit = async (messageId: string) => {
    if (!editText.trim()) return;
    
    const db = getDbService();
    try {
      const messageRef = doc(db, PARENT_MESSAGES_COLLECTION, messageId);
      await updateDoc(messageRef, {
        text: editText.trim(),
        edited: true,
        editedAt: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error editing message:', error);
    }
    setEditingMessage(null);
    setEditText('');
  };

  const cancelEdit = () => {
    setEditingMessage(null);
    setEditText('');
  };

  const addReaction = async (messageId: string, emoji: string) => {
    const db = getDbService();
    try {
      const messageRef = doc(db, PARENT_MESSAGES_COLLECTION, messageId);
      const message = messages.find(m => m.id === messageId);
      if (!message) return;

      const reactions = message.reactions || {};
      const emojiKey = emoji;
      const userId = user?.uid || '';
      
      // Get current reactions for this emoji
      const currentReactions = (reactions[emojiKey] as string[]) || [];
      
      // Remove reaction if already added
      if (currentReactions.includes(userId)) {
        const updatedReactions = currentReactions.filter((id: string) => id !== userId);
        if (updatedReactions.length === 0) {
          delete reactions[emojiKey];
        } else {
          reactions[emojiKey] = updatedReactions;
        }
      } else {
        // Add reaction
        reactions[emojiKey] = [...currentReactions, userId];
      }

      await updateDoc(messageRef, { reactions });
    } catch (error) {
      console.error('Error adding reaction:', error);
    }
    setShowActions(null);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);
    setShowMobileActions(false);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // Handle Google Drive file selection
  const handleDriveSelect = async () => {
    setDriveLoading(true);
    try {
      // Request Drive access
      const accessToken = await requestDriveAccess();
      
      // Simple URL prompt for now (can be enhanced with Google Picker)
      const driveUrl = prompt(
        'Paste Google Drive file link:\n\n' +
        'You can get this by:\n' +
        '1. Right-click the file in Drive\n' +
        '2. Click "Share" → "Copy link"'
      );
      
      if (!driveUrl || !driveUrl.trim()) {
        setDriveLoading(false);
        return;
      }
      
      // Parse the URL to get file ID
      const { fileId, valid } = parseDriveUrl(driveUrl.trim());
      
      if (!valid || !fileId) {
        alert('Invalid Google Drive link. Please copy the share link from Drive.');
        setDriveLoading(false);
        return;
      }
      
      // Download the file
      const fileBlob = await getDriveFileContent(fileId, accessToken);
      
      // Determine file extension from URL
      const fileName = `Drive_${fileId}.pdf`;
      
      // Create a File object
      const driveFile = new File([fileBlob], fileName, { type: 'application/pdf' });
      
      setAttachments(prev => [...prev, driveFile]);
      setDriveLoading(false);
    } catch (error: any) {
      console.error('[ParentChat] Drive error:', error);
      setError(error.message || 'Failed to import from Google Drive');
      setDriveLoading(false);
      setTimeout(() => setError(null), 5000);
    }
  };

  const parseDriveUrl = (url: string): { fileId: string; valid: boolean } => {
    const patterns = [
      /\/d\/([a-zA-Z0-9_-]+)\//,
      /\/d\/([a-zA-Z0-9_-]+)$/,
      /id=([a-zA-Z0-9_-]+)/,
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return { fileId: match[1], valid: true };
      }
    }
    
    return { fileId: '', valid: false };
  };

  const formatMessageTime = (date: Date) => {
    return format(date, 'h:mm a');
  };

  // Group messages by date
  const groupedMessages = messages.reduce((groups, message) => {
    const date = format(message.timestamp, 'yyyy-MM-dd');
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {} as Record<string, PrivateMessage[]>);

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 pb-4">
        <h1 className="text-2xl font-bold text-gray-800 flex items-center space-x-2">
          <MessageCircle className="text-purple-500" size={28} />
          <span>Parent Chat</span>
        </h1>
        <div className="flex items-center space-x-2 mt-1">
          <span className="text-gray-500">Private conversation - Hidden from Dominic</span>
        </div>
      </div>

      {/* Messages Container */}
      <div className="flex-1 bg-white rounded-2xl shadow-sm overflow-hidden flex flex-col">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-400">
              <MessageCircle size={48} className="mb-4" />
              <p>No messages yet</p>
              <p className="text-sm">Start coordinating!</p>
            </div>
          ) : (
            Object.entries(groupedMessages).map(([date, dateMessages]) => (
              <div key={date}>
                {/* Date Separator */}
                <div className="flex items-center justify-center my-4">
                  <span className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
                    {format(new Date(date), 'MMMM d, yyyy')}
                  </span>
                </div>

                {/* Messages */}
                {dateMessages.map((message) => {
                  const isOwnMessage = message.senderId === user?.uid;

                  return (
                    <div
                      key={message.id}
                      className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'} mb-3 group`}
                    >
                      <div className="relative group">
                        <div
                          className={`max-w-[85%] rounded-2xl px-5 py-3 ${
                            isOwnMessage
                              ? 'bg-purple-100 rounded-br-md'
                              : 'bg-white border border-gray-200 rounded-bl-md'
                          }`}
                        >
                          {!isOwnMessage && (
                            <p className="text-xs font-semibold text-gray-600 mb-1.5">
                              {message.senderName}
                            </p>
                          )}

                          {/* Edit Mode */}
                          {editingMessage?.id === message.id ? (
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={editText}
                                onChange={(e) => setEditText(e.target.value)}
                                className="flex-1 px-2 py-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                                autoFocus
                              />
                              <button onClick={() => saveEdit(message.id)} className="text-green-500">
                                <Check size={16} />
                              </button>
                              <button onClick={cancelEdit} className="text-red-500">
                                <X size={16} />
                              </button>
                            </div>
                          ) : (
                            <>
                              {/* Text Content */}
                              {message.text && (
                                <p
                                  className={`text-base leading-relaxed ${
                                    isOwnMessage ? 'text-gray-800' : 'text-gray-700'
                                  }`}
                                >
                                  {message.text}
                                </p>
                              )}

                              {/* Attachments */}
                              {message.attachments && message.attachments.length > 0 && (
                                <div className="mt-3 space-y-2">
                                  {message.attachments.map((attachment) => (
                                    <div key={attachment.id} className="attachment-item">
                                      {attachment.fileType === 'image' ? (
                                        <img 
                                          src={attachment.url} 
                                          alt={attachment.title}
                                          className="max-w-full rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                          onClick={() => window.open(attachment.url, '_blank')}
                                        />
                                      ) : (
                                        <a 
                                          href={attachment.url} 
                                          target="_blank" 
                                          rel="noopener noreferrer"
                                          className="flex items-center gap-2 text-blue-500 hover:underline"
                                        >
                                          <Paperclip size={16} />
                                          <span>{attachment.title}</span>
                                        </a>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Edited indicator */}
                              {message.edited && (
                                <p className="text-[10px] text-gray-400 mt-1.5">
                                  edited
                                </p>
                              )}

                              {/* Reactions display */}
                              {message.reactions && Object.keys(message.reactions).length > 0 && (
                                <div className="flex flex-wrap gap-1.5 mt-3">
                                  {Object.entries(message.reactions).map(([emoji, users]) => (
                                    <button
                                      key={emoji}
                                      onClick={() => addReaction(message.id, emoji)}
                                      className={`text-sm px-2.5 py-1 rounded-full border ${
                                        (users as unknown as string[]).includes(user?.uid || '')
                                          ? 'bg-purple-100 border-purple-300 text-purple-700'
                                          : 'bg-gray-100 border-gray-300 text-gray-700'
                                      }`}
                                    >
                                      <span className="mr-1">{emoji}</span>
                                      <span className="text-xs font-medium">{(users as unknown as string[]).length}</span>
                                    </button>
                                  ))}
                                </div>
                              )}

                              {/* Time and actions */}
                              <div className="flex items-center justify-between mt-2 pt-1 border-t border-black/5">
                                <p
                                  className={`text-[11px] text-gray-400 ${
                                    isOwnMessage ? '' : ''
                                  }`}
                                >
                                  {formatMessageTime(message.timestamp)}
                                </p>

                                {/* Quick reactions */}
                                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all duration-200 translate-y-1 group-hover:translate-y-0">
                                  {QUICK_REACTIONS.slice(0, 3).map((emoji) => (
                                    <button
                                      key={emoji}
                                      onClick={() => addReaction(message.id, emoji)}
                                      className="w-7 h-7 flex items-center justify-center text-lg bg-white rounded-full shadow-sm border border-gray-200 hover:scale-110 hover:shadow-md transition-all"
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </>
                          )}
                        </div>

                        {/* Action menu (three dots) */}
                        {isOwnMessage && !editingMessage && (
                          <button
                            onClick={() => setShowActions(showActions === message.id ? null : message.id)}
                            className="absolute -right-10 top-1 p-1.5 text-gray-400 hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-all duration-200"
                          >
                            <MoreVertical size={16} />
                          </button>
                        )}

                        {/* Actions dropdown */}
                        {showActions === message.id && (
                          <div className="absolute right-0 top-6 bg-white shadow-lg rounded-lg py-1 z-10 min-w-[120px]">
                            <button
                              onClick={() => startEdit(message)}
                              className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center gap-2"
                            >
                              <Edit2 size={14} />
                              Edit
                            </button>
                            <button
                              onClick={() => deleteMessage(message.id)}
                              className="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center gap-2 text-red-500"
                            >
                              <Trash2 size={14} />
                              Delete
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Attachment previews */}
        {attachments.length > 0 && (
          <div className="flex-shrink-0 px-4 py-2 bg-gray-50 border-t border-gray-100">
            <div className="flex flex-wrap gap-2">
              {attachments.map((file, index) => (
                <div key={index} className="relative group">
                  {file.type.startsWith('image/') ? (
                    <img
                      src={URL.createObjectURL(file)}
                      alt={file.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                      <Paperclip size={20} />
                    </div>
                  )}
                  <button
                    onClick={() => removeAttachment(index)}
                    className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
            
            {/* Upload Progress Bar */}
            {uploadProgress !== null && (
              <div className="mt-3">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                  <span>{sending ? 'Uploading...' : 'Processing...'}</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="flex-shrink-0 px-4 py-3 bg-red-100 border-t border-red-300">
            <div className="flex items-center justify-between">
              <p className="text-red-700 text-sm font-medium flex-1">{error}</p>
              <button onClick={() => setError(null)} className="text-red-500 hover:text-red-700 ml-2">
                <X size={16} />
              </button>
            </div>
          </div>
        )}

        {/* Message Input */}
        <form
          onSubmit={sendMessage}
          className="flex-shrink-0 border-t border-gray-100 p-4 bg-gray-50"
        >
          <div className="flex items-center gap-2">
            {/* Mobile actions button */}
            <button
              type="button"
              onClick={() => setShowMobileActions(!showMobileActions)}
              className="lg:hidden p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
            >
              <Plus size={20} />
            </button>

            {/* Mobile attachment buttons */}
            <div className={`${showMobileActions ? 'flex' : 'hidden'} lg:flex items-center gap-2`}>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                multiple
                accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
                title="Attach file"
              >
                <Paperclip size={20} />
              </button>
              
              <input
                type="file"
                ref={cameraInputRef}
                onChange={handleFileSelect}
                accept="image/*"
                capture="environment"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
                title="Take photo"
              >
                <Camera size={20} />
              </button>
              
              {/* Google Drive Button */}
              <button
                type="button"
                onClick={handleDriveSelect}
                disabled={driveLoading}
                className="p-2 text-blue-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                title="Add from Google Drive"
              >
                {driveLoading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500" />
                ) : (
                  <Cloud size={20} />
                )}
              </button>
            </div>

            {/* Emoji picker toggle */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
              >
                <Smile size={20} />
              </button>

              {/* Emoji picker dropdown */}
              {showEmojiPicker && (
                <div className="absolute bottom-full left-0 mb-2 bg-white shadow-lg rounded-lg p-2 grid grid-cols-6 gap-1 w-48">
                  {['😀', '😂', '🥰', '😮', '😢', '😡', '👍', '👎', '❤️', '🎉', '🎊', '🎁', '🔥', '⭐', '💯', '🙏', '💪', '👋', '🎵', '💡'].map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => {
                        setNewMessage(prev => prev + emoji);
                        setShowEmojiPicker(false);
                      }}
                      className="text-xl p-1 hover:bg-gray-100 rounded"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => {
                console.log('[ParentChat] Key pressed:', e.key, 'Enter?', e.key === 'Enter');
                if (e.key === 'Enter' && !e.shiftKey) {
                  console.log('[ParentChat] Enter pressed, calling sendMessage...');
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder="Type a private message..."
              className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
            <button
              type="submit"
              disabled={sending || (!newMessage.trim() && attachments.length === 0)}
              className="p-3 bg-purple-500 text-white rounded-full hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center min-w-[48px]"
            >
              {sending ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
              ) : (
                <span className="text-lg">➤</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ParentChat;
