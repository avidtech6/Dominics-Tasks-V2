import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TasksProvider, useTasks } from './context/TasksContext';
import { FamilyProvider, useFamily } from './context/FamilyContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Tasks from './pages/Tasks';
import Calendar from './pages/Calendar';
import FamilyChat from './pages/FamilyChat';
import ParentChat from './pages/ParentChat';
import Resources from './pages/Resources';
import History from './pages/History';
import Achievements from './pages/Achievements';
import TaskComment from './pages/TaskComment';
import ProfileSelectionScreen from './components/ProfileSelectionScreen';
import FamilySetupScreen from './components/FamilySetupScreen';

// Loading spinner
const LoadingScreen: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-3 border-blue-600 mx-auto mb-6"></div>
        <p className="text-xl text-gray-700 font-semibold">
          Loading Dominic's Tasks
        </p>
        <p className="text-gray-500 mt-2">
          Please wait...
        </p>
      </div>
    </div>
  );
};

// Login page wrapper
const LoginPage: React.FC = () => {
  const { error } = useAuth();
  return <Login error={error} />;
};

// Profile Selection Page - shows after login
const ProfileSelectionPage: React.FC = () => {
  const { user } = useAuth();
  const { needsSetup, currentProfileId, isParentMode } = useFamily();
  const navigate = useNavigate();

  const handleProfileSelect = (profileId: string) => {
    // Profile is already selected in FamilyContext
    // Navigate to tasks with the selected profile
    navigate('/tasks');
  };

  const handleParentMode = () => {
    // Parent mode is already activated in FamilyContext
    // Navigate to admin dashboard
    navigate('/admin');
  };

  // If setup is needed, show setup screen
  if (needsSetup && user) {
    return <FamilySetupScreen onComplete={() => navigate('/profile-select')} />;
  }

  // If already in parent mode, redirect to admin
  if (isParentMode) {
    return <Navigate to="/admin" replace />;
  }

  // If already have a profile selected, redirect to tasks
  if (currentProfileId) {
    return <Navigate to="/tasks" replace />;
  }

  return (
    <ProfileSelectionScreen
      onProfileSelect={handleProfileSelect}
      onParentMode={handleParentMode}
    />
  );
};

// Protected page wrapper - handles auth check and profile selection
const ProtectedPage: React.FC<{
  children: React.ReactNode;
  requireParent?: boolean;
}> = ({ children, requireParent = false }) => {
  const { user, loading, isParent } = useAuth();
  const { currentProfileId, isParentMode, isLoading, needsSetup } = useFamily();

  if (loading || isLoading) {
    return <LoadingScreen />;
  }

  // If not authenticated, show login
  if (!user) {
    return <LoginPage />;
  }

  // If setup is needed, redirect to setup
  if (needsSetup) {
    return <Navigate to="/profile-select" replace />;
  }

  // If parent-only route but user is not a parent, redirect to tasks
  if (requireParent && !isParent) {
    return <Navigate to="/tasks" replace />;
  }

  // If in parent mode but trying to access child-only route
  if (isParentMode && !requireParent) {
    // Allow access but show parent indicators
  }

  // If not in parent mode and no profile selected, redirect to profile selection
  if (!isParentMode && !currentProfileId) {
    return <Navigate to="/profile-select" replace />;
  }

  // User is authenticated and has selected a profile - show the page with layout
  return <Layout>{children}</Layout>;
};

// Parent/Admin page wrapper
const AdminPage: React.FC<{
  children: React.ReactNode;
}> = ({ children }) => {
  const { user, loading, isParent } = useAuth();
  const { isParentMode, isLoading, needsSetup } = useFamily();

  if (loading || isLoading) {
    return <LoadingScreen />;
  }

  // If not authenticated, show login
  if (!user) {
    return <LoginPage />;
  }

  // If setup is needed, redirect to setup
  if (needsSetup) {
    return <Navigate to="/profile-select" replace />;
  }

  // If not in parent mode, redirect to profile selection
  if (!isParentMode) {
    return <Navigate to="/profile-select" replace />;
  }

  // User is authenticated and in parent mode - show admin layout
  return <Layout>{children}</Layout>;
};

// Main App component
const App: React.FC = () => {
  console.log('[App] Rendering App component');

  return (
    <BrowserRouter>
      <AuthProvider>
        <FamilyProvider>
          <TasksProvider>
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<LoginPage />} />
              <Route path="/login" element={<LoginPage />} />

              {/* Profile selection (first-time setup or profile switch) */}
              <Route path="/profile-select" element={<ProfileSelectionPage />} />

              {/* Protected routes */}
              <Route path="/tasks" element={
                <ProtectedPage>
                  <Tasks />
                </ProtectedPage>
              } />
              <Route path="/calendar" element={
                <ProtectedPage>
                  <Calendar />
                </ProtectedPage>
              } />
              <Route path="/chat" element={
                <ProtectedPage>
                  <FamilyChat />
                </ProtectedPage>
              } />
              <Route path="/parent-chat" element={
                <ProtectedPage requireParent>
                  <ParentChat />
                </ProtectedPage>
              } />
              <Route path="/resources" element={
                <ProtectedPage>
                  <Resources />
                </ProtectedPage>
              } />
              <Route path="/history" element={
                <ProtectedPage>
                  <History />
                </ProtectedPage>
              } />
              <Route path="/achievements" element={
                <ProtectedPage>
                  <Achievements />
                </ProtectedPage>
              } />
              <Route path="/task-comment/:taskId" element={
                <ProtectedPage requireParent>
                  <TaskComment />
                </ProtectedPage>
              } />

              {/* Admin routes (parent mode) */}
              <Route path="/admin" element={
                <AdminPage>
                  <div style={{ padding: '24px' }}>
                    <h1>Parent Dashboard</h1>
                    <p>Admin console coming soon...</p>
                  </div>
                </AdminPage>
              } />

              {/* Redirects */}
              <Route index element={<Navigate to="/tasks" replace />} />
              <Route path="*" element={<Navigate to="/tasks" replace />} />
            </Routes>
          </TasksProvider>
        </FamilyProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
