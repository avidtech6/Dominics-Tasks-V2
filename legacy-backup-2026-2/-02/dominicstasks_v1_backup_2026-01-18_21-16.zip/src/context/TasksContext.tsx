import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import {
  collection,
  query,
  where,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  getDocs,
} from 'firebase/firestore';
import { getDbService } from '../services/firebase';
import { useAuth } from './AuthContext';
import { Task, TaskStatus, TaskSection } from '../types';
import { isDevMode, devTasks } from '../services/devMode';

interface TasksContextType {
  tasks: Task[];
  loading: boolean;
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'createdBy' | 'order'>) => Promise<void>;
  updateTask: (id: string, updates: Partial<Task>) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;
  restoreDeletedTask: (id: string) => Promise<void>;
  permanentlyDeleteTask: (id: string) => Promise<void>;
  completeTask: (id: string) => Promise<void>;
  uncompleteTask: (id: string) => Promise<void>;
  archiveTask: (id: string) => Promise<void>;
  reviveTask: (id: string) => Promise<void>;
  moveTask: (id: string, section: TaskSection, status: TaskStatus) => Promise<void>;
  getTasksByDate: (date: Date) => Task[];
  getTasksByDeadline: () => Task[];
  getOverdueTasks: () => Task[];
  getHistoryTasks: () => Task[];
  getDeletedTasks: () => Task[];
  getCompletedTodayTasks: () => Task[];
  // Comment functions
  addTaskComment: (taskId: string, taskTitle: string, text: string) => Promise<void>;
  getTaskComments: (taskId: string) => Promise<any[]>;
}

const TasksContext = createContext<TasksContextType | null>(null);

export const useTasks = () => {
  const context = useContext(TasksContext);
  if (!context) {
    throw new Error('useTasks must be used within a TasksProvider');
  }
  return context;
};

// Helper to get AUTHORIZED_EMAILS
const AUTHORIZED_EMAILS = [
  'dominicgiles691@gmail.com',
  'derrickmg.admin@gmail.com',
  'brendamgiles@gmail.com',
];

export const TasksProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  // Check dev mode once using lazy initialization to avoid side effects in render
  const [isDev] = useState(() => {
    if (typeof window !== 'undefined') {
      return new URLSearchParams(window.location.search).get('dev') === 'true';
    }
    return false;
  });

  // Fetch tasks in real-time
  useEffect(() => {
    console.log('🔧 TasksContext useEffect, isDev:', isDev);
    
    // Check for dev mode FIRST
    if (isDev) {
      console.log('🔧 DEV MODE: Loading mock tasks');
      setTasks(devTasks as unknown as Task[]);
      setLoading(false);
      console.log('🔧 DEV MODE: Mock tasks set, returning early');
      return;
    }

    console.log('🔧 NOT DEV MODE, setting up Firestore...');
    
    if (!user) {
      console.log('🔧 No user, clearing tasks and returning');
      setTasks([]);
      setLoading(false);
      return;
    }

    const db = getDbService();
    console.log('🔧 DB service obtained:', db ? 'db object' : 'null');
    
    if (!db) {
      console.log('🔧 No database available, using mock tasks');
      setTasks(devTasks as unknown as Task[]);
      setLoading(false);
      return;
    }

    const tasksRef = collection(db, 'tasks');
    const q = query(tasksRef, where('createdBy', 'in', AUTHORIZED_EMAILS));

    console.log('🔧 Setting up onSnapshot...');
    
    // Set loading to false after a timeout in case onSnapshot never fires
    const loadingTimeout = setTimeout(() => {
      console.log('🔧 Loading timeout - forcing loading to false');
      setLoading(false);
    }, 5000);

    const unsubscribe = onSnapshot(q, (snapshot) => {
      console.log('🔧 onSnapshot success, got', snapshot.docs.length, 'tasks');
      clearTimeout(loadingTimeout);
      
      const tasksData: Task[] = snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          dueDate: data.dueDate?.toDate(),
          deadlineDate: data.deadlineDate?.toDate(),
          createdAt: data.createdAt?.toDate(),
          completedAt: data.completedAt?.toDate(),
          archivedAt: data.archivedAt?.toDate(),
          deletedAt: data.deletedAt?.toDate(),
        } as Task;
      });
      setTasks(tasksData);
      setLoading(false);
      console.log('🔧 Tasks loaded, loading false');
    }, (error) => {
      console.error('🔧 onSnapshot error:', error.message);
      clearTimeout(loadingTimeout);
      setLoading(false);
    });

    return () => {
      console.log('🔧 Cleaning up onSnapshot');
      clearTimeout(loadingTimeout);
      unsubscribe();
    };
  }, [user]);

  const addTask = async (taskData: Omit<Task, 'id' | 'createdAt' | 'createdBy' | 'order'>) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    const db = getDbService();
    const tasksRef = collection(db, 'tasks');
    const newTask = {
      ...taskData,
      createdBy: user.email,
      createdAt: serverTimestamp(),
      order: tasks.length,
    };

    try {
      await addDoc(tasksRef, newTask);
    } catch (error) {
      console.error('Error adding task to Firestore:', error);
      throw new Error('Failed to save task. Please check your connection and try again.');
    }
  };

  const updateTask = async (id: string, updates: Partial<Task>) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const db = getDbService();
      await updateDoc(doc(getDbService(), 'tasks', id), updates);
    } catch (error) {
      console.error('Error updating task in Firestore:', error);
      throw new Error('Failed to update task. Please check your connection and try again.');
    }
  };

  const deleteTask = async (id: string) => {
    // Soft delete - mark as deleted but keep in database
    try {
      const db = getDbService();
      await updateDoc(doc(getDbService(), 'tasks', id), {
        deletedAt: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      throw new Error('Failed to delete task. Please try again.');
    }
  };

  const restoreDeletedTask = async (id: string) => {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    // Restore to original status based on section
    const newStatus = task.section === 'morning' || task.section === 'afternoon' ? 'today' : 'todo';

    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        status: newStatus,
        deletedAt: null,
        archivedAt: null,
        completedAt: null,
      });
    } catch (error) {
      console.error('Error restoring task:', error);
      throw new Error('Failed to restore task. Please try again.');
    }
  };

  const permanentlyDeleteTask = async (id: string) => {
    // Permanently remove from database
    try {
      const db = getDbService();
      await deleteDoc(doc(db, 'tasks', id));
    } catch (error) {
      console.error('Error permanently deleting task:', error);
      throw new Error('Failed to permanently delete task. Please try again.');
    }
  };

  const completeTask = async (id: string) => {
    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        status: 'done',
        completedAt: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error completing task:', error);
      throw new Error('Failed to complete task. Please try again.');
    }
  };

  const uncompleteTask = async (id: string) => {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    // Move back to original status based on section
    const newStatus = task.section === 'morning' || task.section === 'afternoon' ? 'today' : 'todo';

    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        status: newStatus,
        completedAt: null,
        archivedAt: null,
      });
    } catch (error) {
      console.error('Error uncompleting task:', error);
      throw new Error('Failed to uncomplete task. Please try again.');
    }
  };

  const archiveTask = async (id: string) => {
    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        archivedAt: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error archiving task:', error);
      throw new Error('Failed to archive task. Please try again.');
    }
  };

  const reviveTask = async (id: string) => {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    // Move back to original section and status
    const newStatus = task.section === 'morning' || task.section === 'afternoon' ? 'today' : 'todo';

    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        status: newStatus,
        archivedAt: null,
        completedAt: null,
      });
    } catch (error) {
      console.error('Error reviving task:', error);
      throw new Error('Failed to revive task. Please try again.');
    }
  };

  const moveTask = async (id: string, section: TaskSection, status: TaskStatus) => {
    try {
      await updateDoc(doc(getDbService(), 'tasks', id), {
        section,
        status,
      });
    } catch (error) {
      console.error('Error moving task:', error);
      throw new Error('Failed to move task. Please try again.');
    }
  };

  const getTasksByDate = useCallback((date: Date): Task[] => {
    const dateStr = date.toDateString();
    return tasks.filter((task) => {
      const taskDate = task.dueDate?.toDateString();
      return taskDate === dateStr && task.status !== 'done' && !task.archivedAt && !task.deletedAt;
    });
  }, [tasks]);

  const getTasksByDeadline = useCallback((): Task[] => {
    const now = new Date();
    return tasks
      .filter((task) => task.deadlineDate && task.deadlineDate > now && task.status !== 'done' && !task.archivedAt && !task.deletedAt)
      .sort((a, b) => (a.deadlineDate?.getTime() || 0) - (b.deadlineDate?.getTime() || 0));
  }, [tasks]);

  const getOverdueTasks = useCallback((): Task[] => {
    const now = new Date();
    return tasks.filter(
      (task) =>
        ((task.deadlineDate && task.deadlineDate < now && task.status !== 'done') ||
        (task.dueDate && task.dueDate < now && task.status === 'todo')) &&
        !task.archivedAt &&
        !task.deletedAt
    );
  }, [tasks]);

  const getHistoryTasks = useCallback((): Task[] => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    thirtyDaysAgo.setHours(0, 0, 0, 0);

    return tasks.filter((task) => 
      task.archivedAt && task.archivedAt >= thirtyDaysAgo && !task.deletedAt
    ).sort((a, b) => ((b.archivedAt?.getTime() || 0) - (a.archivedAt?.getTime() || 0)));
  }, [tasks]);

  const getDeletedTasks = useCallback((): Task[] => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    thirtyDaysAgo.setHours(0, 0, 0, 0);

    return tasks.filter((task) => 
      task.deletedAt && task.deletedAt >= thirtyDaysAgo
    ).sort((a, b) => ((b.deletedAt?.getTime() || 0) - (a.deletedAt?.getTime() || 0)));
  }, [tasks]);

  const getCompletedTodayTasks = useCallback((): Task[] => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return tasks.filter((task) => 
      task.status === 'done' && 
      !task.archivedAt &&
      !task.deletedAt &&
      task.completedAt && 
      task.completedAt >= today &&
      task.completedAt < tomorrow
    );
  }, [tasks]);

  // Add a comment to a task and auto-post to Family Chat
  const addTaskComment = async (taskId: string, taskTitle: string, text: string) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    const db = getDbService();

    // 1. Add comment to task's comments subcollection
    const commentsRef = collection(db, 'tasks', taskId, 'comments');
    await addDoc(commentsRef, {
      text,
      authorId: user.uid,
      authorName: user.displayName,
      authorEmail: user.email,
      timestamp: serverTimestamp(),
    });

    // 2. Increment comment count on task
    const task = tasks.find(t => t.id === taskId);
    const newCount = (task?.commentCount || 0) + 1;
    await updateDoc(doc(db, 'tasks', taskId), {
      commentCount: newCount
    });

    // 3. Auto-post to Family Chat
    try {
      const chatRef = collection(db, 'family_messages');
      await addDoc(chatRef, {
        text: `💬 Comment on "${taskTitle}": ${text}`,
        senderId: user.uid,
        senderName: user.displayName,
        senderEmail: user.email,
        timestamp: serverTimestamp(),
        type: 'system',
        systemEvent: 'task_comment',
        relatedTaskId: taskId,
        attachments: [],
        reactions: {},
      });
    } catch (error) {
      console.error('Error posting comment to Family Chat:', error);
      // Don't fail the whole operation if chat post fails
    }
  };

  // Get comments for a task
  const getTaskComments = async (taskId: string): Promise<any[]> => {
    const db = getDbService();
    const commentsRef = collection(db, 'tasks', taskId, 'comments');
    const q = query(commentsRef); // You might want to add orderBy('timestamp', 'asc')

    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: doc.data().timestamp?.toDate() || new Date(),
    }));
  };

  // Auto-move tasks to today's focus if due date is today
  useEffect(() => {
    // Skip in dev mode
    if (isDev) return;
    
    if (!user || tasks.length === 0) return;

    const now = new Date();
    const today = now.toDateString();

    // Use functional update to avoid dependency on tasks
    const moveTasks = async () => {
      const tasksToMove = tasks.filter(task => 
        task.dueDate &&
        task.dueDate.toDateString() === today &&
        task.status === 'todo' &&
        !task.archivedAt &&
        !task.deletedAt
      );
      
      if (tasksToMove.length === 0) return;
      
      const db = getDbService();
      await Promise.all(tasksToMove.map(task => 
        updateDoc(doc(db, 'tasks', task.id), { status: 'today' })
      ));
    };
    
    moveTasks();
  }, [isDev, user]);

  const value: TasksContextType = {
    tasks,
    loading,
    addTask,
    updateTask,
    deleteTask,
    restoreDeletedTask,
    permanentlyDeleteTask,
    completeTask,
    uncompleteTask,
    archiveTask,
    reviveTask,
    moveTask,
    getTasksByDate,
    getTasksByDeadline,
    getOverdueTasks,
    getHistoryTasks,
    getDeletedTasks,
    getCompletedTodayTasks,
    addTaskComment,
    getTaskComments,
  };

  return (
    <TasksContext.Provider value={value}>
      {children}
    </TasksContext.Provider>
  );
};
