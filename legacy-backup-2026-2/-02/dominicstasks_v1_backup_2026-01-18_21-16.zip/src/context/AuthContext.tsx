import React, { createContext, useContext, useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User as FirebaseUser,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
  GoogleAuthProvider,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { getAuthService, getDbService, AUTHORIZED_EMAILS, PARENT_EMAILS, isDevMode, devUser } from '../services/firebase';
import { User, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  firebaseUser: FirebaseUser | null;
  loading: boolean;
  error: string | null;
  signIn: () => Promise<void>;
  signOut: () => Promise<void>;
  isParent: boolean;
  isAuthorized: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const authInitialized = useRef(false);
  const isFirstRender = useRef(true);

  // Helper to determine user role
  const getUserRole = useCallback((email: string): UserRole => {
    return PARENT_EMAILS.includes(email) ? 'parent' : 'student';
  }, []);

  // Create user data from Firebase user
  const createUserData = useCallback((firebaseUserObj: FirebaseUser): User => {
    return {
      uid: firebaseUserObj.uid,
      email: firebaseUserObj.email || '',
      displayName: firebaseUserObj.displayName || 'Unknown',
      photoURL: firebaseUserObj.photoURL || undefined,
      role: getUserRole(firebaseUserObj.email || ''),
      currentStreak: 0,
      totalEP: 0,
      level: 1,
      unlockedAchievements: [],
    };
  }, [getUserRole]);

  // Process authenticated user - runs in background after login
  const processUserInBackground = useCallback(async (firebaseUserObj: FirebaseUser) => {
    const email = firebaseUserObj.email || '';
    console.log('[Auth] Background: Processing user:', email);

    // Check authorization
    if (!AUTHORIZED_EMAILS.includes(email)) {
      console.log('[Auth] Background: User not authorized:', email);
      try {
        const auth = getAuthService();
        await firebaseSignOut(auth);
      } catch (e) {
        console.error('[Auth] Background: Error signing out unauthorized user:', e);
      }
      return;
    }

    try {
      const db = getDbService();
      const userDocRef = doc(db, 'users', firebaseUserObj.uid);
      const userDoc = await getDoc(userDocRef);

      let userData: User;

      if (userDoc.exists()) {
        userData = userDoc.data() as User;
        // Update display name and photo if changed
        userData.displayName = firebaseUserObj.displayName || userData.displayName;
        userData.photoURL = firebaseUserObj.photoURL || userData.photoURL;
      } else {
        userData = createUserData(firebaseUserObj);
      }

      // Save user data
      await setDoc(userDocRef, userData, { merge: true });
      
      console.log('[Auth] Background: User data saved:', email);
    } catch (err) {
      console.error('[Auth] Background: Error saving user data:', err);
      // Non-critical error - user can still use the app
    }
  }, [createUserData, getUserRole]);

  // Handle user login - sets state immediately, processes Firestore in background
  const handleUserLogin = useCallback(async (firebaseUserObj: FirebaseUser) => {
    const email = firebaseUserObj.email || '';
    console.log('[Auth] Handling user login:', email);

    // Check authorization FIRST
    if (!AUTHORIZED_EMAILS.includes(email)) {
      console.log('[Auth] User not authorized:', email);
      setError('You are not authorized to access this application.');
      try {
        const auth = getAuthService();
        await firebaseSignOut(auth);
      } catch (e) {
        console.error('[Auth] Error signing out unauthorized user:', e);
      }
      // Still set loading to false so we can show the error
      setLoading(false);
      return;
    }

    // Create user data immediately
    const userData = createUserData(firebaseUserObj);

    // Update state IMMEDIATELY - this is critical!
    setUser(userData);
    setFirebaseUser(firebaseUserObj);
    setError(null);
    setLoading(false);

    console.log('[Auth] User logged in successfully:', email);

    // Navigate to profile selection - but use a timeout to avoid triggering re-renders during state update
    setTimeout(() => {
      navigate('/profile-select', { replace: true });
    }, 100);

    // Process Firestore operations in the background (don't await)
    processUserInBackground(firebaseUserObj).catch(err => {
      console.error('[Auth] Background processing error:', err);
    });
  }, [createUserData, getUserRole, navigate, processUserInBackground]);

  // Initialize authentication - listen for auth state changes
  useEffect(() => {
    console.log('[Auth] Setting up auth state listener...');

    // On first render, check if we already have a user in state
    if (isFirstRender.current) {
      isFirstRender.current = false;
      // If we already have a user from initial render, mark as initialized
      if (user) {
        authInitialized.current = true;
        setLoading(false);
        console.log('[Auth] Already have user on first render');
        return;
      }
    }

    // On subsequent renders (navigations), if already initialized, don't reset
    if (authInitialized.current && user) {
      console.log('[Auth] Already initialized with user, skipping re-setup');
      setLoading(false);
      return;
    }

    // Check for dev mode
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('dev') === 'true') {
      console.log('[Auth] Dev mode detected, using mock user');
      setUser(devUser);
      setFirebaseUser({
        uid: devUser.uid,
        email: devUser.email,
        displayName: devUser.displayName,
        photoURL: devUser.photoURL,
      } as FirebaseUser);
      authInitialized.current = true;
      setLoading(false);
      return;
    }

    const auth = getAuthService();
    if (!auth) {
      console.log('[Auth] Auth service not available');
      authInitialized.current = true;
      setLoading(false);
      return;
    }

    // Set persistence to local storage (CRITICAL for keeping user logged in)
    setPersistence(auth, browserLocalPersistence).catch((err) => {
      console.warn('[Auth] Could not set persistence:', err);
    });

    // Check for redirect result (from mobile sign-in)
    // This handles the case when user returns from Google sign-in redirect
    const checkRedirectResult = async () => {
      try {
        const result = await getRedirectResult(auth);
        if (result?.user) {
          console.log('[Auth] Redirect sign-in result detected');
          await handleUserLogin(result.user);
          authInitialized.current = true;
          return true;
        }
      } catch (err: any) {
        console.error('[Auth] Redirect result error:', err.code, err.message);
        if (err.code === 'auth/unauthorized-domain') {
          setError('This domain is not authorized. Please contact the app administrator.');
        } else if (err.message?.includes('unauthorized')) {
          setError('You are not authorized to access this application.');
        }
        setLoading(false);
      }
      return false;
    };

    // Check redirect result before setting up listener
    checkRedirectResult();

    let hasLoggedInitialState = false;

    // Listen for auth state changes
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUserObj) => {
      console.log('[Auth] Auth state changed:', firebaseUserObj ? 'user present' : 'no user');
      
      // Skip the very first "no user" state if we haven't initialized yet
      // Firebase always fires an initial "no user" event
      if (!hasLoggedInitialState && !firebaseUserObj && !authInitialized.current) {
        console.log('[Auth] Ignoring initial "no user" state');
        hasLoggedInitialState = true;
        return;
      }
      
      // If we have a user already in state and Firebase says "no user", 
      // this might be Firebase's initialization - preserve our state
      if (authInitialized.current && !firebaseUserObj && user) {
        console.log('[Auth] Ignoring auth state change - preserving existing user');
        setLoading(false);
        return;
      }
      
      if (firebaseUserObj) {
        await handleUserLogin(firebaseUserObj);
        authInitialized.current = true;
      } else {
        // User actually signed out - reset state
        console.log('[Auth] User signed out - resetting state');
        setUser(null);
        setFirebaseUser(null);
        authInitialized.current = false;
        setLoading(false);
      }
    });

    // Cleanup
    return () => {
      console.log('[Auth] Cleaning up auth listener');
      unsubscribe();
    };
  }, [handleUserLogin, user]);

  // Safety timeout - ensure we don't stay in loading state forever
  useEffect(() => {
    if (loading) {
      const timeout = setTimeout(() => {
        console.log('[Auth] Safety timeout - forcing loading to false');
        setLoading(false);
      }, 10000);

      return () => clearTimeout(timeout);
    }
  }, [loading]);

  // Detect if device is mobile
  const isMobileDevice = () => {
    if (typeof window === 'undefined') return false;
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    );
  };

  // Sign in function - using redirect on mobile for better compatibility
  const signIn = async () => {
    try {
      console.log('[Auth] Initiating sign-in...');
      setLoading(true);
      setError(null);

      if (isDevMode()) {
        console.log('[Auth] Dev mode, using mock user');
        setUser(devUser);
        setFirebaseUser({
          uid: devUser.uid,
          email: devUser.email,
          displayName: devUser.displayName,
          photoURL: devUser.photoURL,
        } as FirebaseUser);
        authInitialized.current = true;
        setLoading(false);
        navigate('/tasks', { replace: true });
        return;
      }

      const auth = getAuthService();

      // Create Google provider with account selection prompt
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account' // Always show account picker
      });

      // Use redirect on mobile devices, popup on desktop
      const isMobile = isMobileDevice();

      if (isMobile) {
        console.log('[Auth] Mobile device detected, using redirect sign-in...');
        await signInWithRedirect(auth, provider);
      } else {
        console.log('[Auth] Desktop detected, using popup sign-in...');
        await signInWithPopup(auth, provider);
      }

      console.log('[Auth] Sign-in initiated successfully!');

      // The onAuthStateChanged listener will handle processing the user
      // For redirect, the result will be processed when the page redirects back

    } catch (err: any) {
      console.error('[Auth] Sign-in error:', err.code, err.message);

      // Handle specific errors
      if (err.code === 'auth/popup-blocked') {
        setError('Popup was blocked by your browser. Please try again by clicking the button once more, or use Chrome browser.');
      } else if (err.code === 'auth/popup-closed-by-user') {
        setError('Sign-in popup was closed before completing. Please try again.');
      } else if (err.code === 'auth/network-request-failed') {
        setError('Network error. Please check your internet connection and try again.');
      } else if (err.code === 'auth/unauthorized-domain') {
        setError('This domain is not authorized. Please contact the app administrator.');
      } else if (err.message?.includes('unauthorized')) {
        setError('You are not authorized to access this application.');
      } else {
        setError(`Sign-in error: ${err.message || 'Unknown error'}`);
      }

      setLoading(false);
    }
  };

  // Sign out function
  const signOut = async () => {
    try {
      const auth = getAuthService();
      await firebaseSignOut(auth);
      setUser(null);
      setFirebaseUser(null);
      navigate('/', { replace: true });
    } catch (err) {
      console.error('[Auth] Sign-out error:', err);
      setError('Error signing out.');
    }
  };

  // Computed values
  const isParent = user?.role === 'parent';
  const isAuthorized = !!user && AUTHORIZED_EMAILS.includes(user.email);

  const value: AuthContextType = {
    user,
    firebaseUser,
    loading,
    error,
    signIn,
    signOut,
    isParent,
    isAuthorized,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
