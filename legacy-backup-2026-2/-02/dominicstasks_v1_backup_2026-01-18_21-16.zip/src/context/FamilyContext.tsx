import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  query,
  where,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { getDbService } from '../services/firebase';
import { useAuth } from './AuthContext';
import {
  Family,
  FamilySettings,
  ChildProfile,
  ChildSettings,
  ProfileMode,
  CHILD_AVATARS,
  CHILD_THEME_COLORS,
  ApprovalLevel,
} from '../types';

// Simple SHA-256 hash function for PIN
async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

// Default child settings
const DEFAULT_CHILD_SETTINGS: ChildSettings = {
  pointsEnabled: true,
  morningBonusEnabled: true,
  morningBonusDeadline: '13:00',
  deadlineWarningsEnabled: true,
  autoAfternoonMoveEnabled: true,
  autoAfternoonMoveTime: '13:00',
  timerEnabled: true,
  historyEnabled: true,
  doTomorrowEnabled: true,
  shopEnabled: true,
  leaderboardEnabled: false, // Off by default to avoid competitive stress
  achievementsEnabled: true,
  defaultApprovalLevel: 0, // No approval required by default
};

interface FamilyContextType {
  // State
  family: Family | null;
  currentProfileId: string | null;
  currentProfile: ChildProfile | null;
  isParentMode: boolean;
  isLoading: boolean;
  needsSetup: boolean;
  
  // Profile management
  profiles: ChildProfile[];
  selectProfile: (profileId: string) => Promise<void>;
  enterParentMode: (pin: string) => Promise<boolean>;
  exitParentMode: () => void;
  
  // Child management
  createChildProfile: (name: string, avatar: string, themeColor: string, age?: number) => Promise<string>;
  updateChildProfile: (profileId: string, updates: Partial<ChildProfile>) => Promise<void>;
  deleteChildProfile: (profileId: string) => Promise<void>;
  
  // Settings management
  setupParentPin: (pin: string) => Promise<void>;
  updateParentSettings: (settings: Partial<FamilySettings>) => Promise<void>;
  updateChildSettings: (profileId: string, settings: Partial<ChildSettings>) => Promise<void>;
  
  // Profile switching from child mode
  showProfileSwitcher: boolean;
  setShowProfileSwitcher: (show: boolean) => void;
}

const FamilyContext = createContext<FamilyContextType | null>(null);

export const useFamily = () => {
  const context = useContext(FamilyContext);
  if (!context) {
    throw new Error('useFamily must be used within a FamilyProvider');
  }
  return context;
};

interface FamilyProviderProps {
  children: ReactNode;
}

export const FamilyProvider: React.FC<FamilyProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [family, setFamily] = useState<Family | null>(null);
  const [currentProfileId, setCurrentProfileId] = useState<string | null>(null);
  const [isParentMode, setIsParentMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [showProfileSwitcher, setShowProfileSwitcher] = useState(false);
  const [unsubscribe, setUnsubscribe] = useState<(() => void) | null>(null);

  // Get list of child profiles from family data
  const profiles: ChildProfile[] = family ? Object.entries(family.children || {}).map(([id, child]) => ({
    ...child,
    id,
  })) : [];

  // Current profile object
  const currentProfile: ChildProfile | null = currentProfileId && family?.children?.[currentProfileId]
    ? { ...family.children[currentProfileId], id: currentProfileId }
    : null;

  // Load family data on auth change
  useEffect(() => {
    if (!user) {
      setFamily(null);
      setCurrentProfileId(null);
      setIsParentMode(false);
      setIsLoading(false);
      return;
    }

    const loadFamilyData = async () => {
      setIsLoading(true);
      try {
        const db = getDbService();
        const familyDocRef = doc(db, 'families', user.uid);
        const familyDoc = await getDoc(familyDocRef);

        if (familyDoc.exists()) {
          const familyData = familyDoc.data() as Family;
          setFamily(familyData);
          setNeedsSetup(false);

          // Setup real-time listener
          const newUnsubscribe = onSnapshot(familyDocRef, (snapshot) => {
            if (snapshot.exists()) {
              setFamily(snapshot.data() as Family);
            }
          });
          setUnsubscribe(() => newUnsubscribe);

          // Auto-select first profile if none selected
          const children = familyData.children || {};
          const childIds = Object.keys(children);
          if (childIds.length > 0 && !currentProfileId) {
            const savedProfileId = localStorage.getItem(`family_${user.uid}_currentProfile`);
            if (savedProfileId && children[savedProfileId]) {
              setCurrentProfileId(savedProfileId);
            } else {
              setCurrentProfileId(childIds[0]);
            }
          }
        } else {
          // First time setup needed
          setFamily({
            id: user.uid,
            settings: {
              parentId: user.uid,
              hasPinSetup: false,
              biometricEnabled: false,
              familyName: user.displayName || 'Our Family',
              theme: 'light',
              notificationsEnabled: true,
              emailNotificationsEnabled: true,
            },
            children: {},
            createdAt: new Date(),
            updatedAt: new Date(),
          });
          setNeedsSetup(true);
        }
      } catch (error) {
        console.error('Error loading family data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadFamilyData();

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [user]);

  // Select a child profile
  const selectProfile = useCallback(async (profileId: string) => {
    if (!user || !family?.children?.[profileId]) {
      throw new Error('Invalid profile selection');
    }

    setCurrentProfileId(profileId);
    setIsParentMode(false);
    localStorage.setItem(`family_${user.uid}_currentProfile`, profileId);
  }, [user, family]);

  // Enter parent mode with PIN verification
  const enterParentMode = useCallback(async (pin: string): Promise<boolean> => {
    if (!user || !family?.settings?.pinHash) {
      return false;
    }

    const inputHash = await hashPin(pin);
    if (inputHash === family.settings.pinHash) {
      setIsParentMode(true);
      setCurrentProfileId(null); // No child profile active in parent mode
      return true;
    }

    return false;
  }, [user, family]);

  // Exit parent mode
  const exitParentMode = useCallback(() => {
    setIsParentMode(false);
    // Auto-select first profile after exiting parent mode
    if (family) {
      const childIds = Object.keys(family.children || {});
      if (childIds.length > 0) {
        setCurrentProfileId(childIds[0]);
      }
    }
  }, [family]);

  // Create a new child profile
  const createChildProfile = useCallback(async (name: string, avatar: string, themeColor: string, age?: number): Promise<string> => {
    if (!user || !family) {
      throw new Error('Must be logged in with a family');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);

    // Generate a new child ID
    const newChildId = `child_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const newChild: ChildProfile = {
      id: newChildId,
      name,
      avatar,
      themeColor,
      age,
      stats: {
        totalEP: 0,
        level: 1,
        currentStreak: 0,
        tasksCompleted: 0,
        totalTasks: 0,
      },
      settings: { ...DEFAULT_CHILD_SETTINGS },
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Update family document
    await updateDoc(familyDocRef, {
      [`children.${newChildId}`]: newChild,
      updatedAt: serverTimestamp(),
    });

    return newChildId;
  }, [user, family]);

  // Update a child profile
  const updateChildProfile = useCallback(async (profileId: string, updates: Partial<ChildProfile>): Promise<void> => {
    if (!user || !family?.children?.[profileId]) {
      throw new Error('Invalid profile');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);

    await updateDoc(familyDocRef, {
      [`children.${profileId}`]: {
        ...family.children[profileId],
        ...updates,
        updatedAt: new Date(),
      },
      updatedAt: serverTimestamp(),
    });
  }, [user, family]);

  // Delete a child profile
  const deleteChildProfile = useCallback(async (profileId: string): Promise<void> => {
    if (!user || !family?.children?.[profileId]) {
      throw new Error('Invalid profile');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);

    // Remove the child from the family document
    await updateDoc(familyDocRef, {
      [`children.${profileId}`]: null,
      updatedAt: serverTimestamp(),
    });

    // If deleting current profile, select another
    if (currentProfileId === profileId) {
      const remainingIds = Object.keys(family.children || {}).filter(id => id !== profileId);
      setCurrentProfileId(remainingIds.length > 0 ? remainingIds[0] : null);
    }
  }, [user, family, currentProfileId]);

  // Setup parent PIN
  const setupParentPin = useCallback(async (pin: string): Promise<void> => {
    if (!user) {
      throw new Error('Must be logged in');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);
    const pinHash = await hashPin(pin);

    await updateDoc(familyDocRef, {
      'settings.pinHash': pinHash,
      'settings.hasPinSetup': true,
      updatedAt: serverTimestamp(),
    });
  }, [user]);

  // Update parent settings
  const updateParentSettings = useCallback(async (settings: Partial<FamilySettings>): Promise<void> => {
    if (!user || !family) {
      throw new Error('Must be logged in with a family');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);

    const updates: Record<string, any> = {};
    for (const [key, value] of Object.entries(settings)) {
      updates[`settings.${key}`] = value;
    }
    updates['updatedAt'] = serverTimestamp();

    await updateDoc(familyDocRef, updates);
  }, [user, family]);

  // Update child settings
  const updateChildSettings = useCallback(async (profileId: string, settings: Partial<ChildSettings>): Promise<void> => {
    if (!user || !family?.children?.[profileId]) {
      throw new Error('Invalid profile');
    }

    const db = getDbService();
    const familyDocRef = doc(db, 'families', user.uid);

    await updateDoc(familyDocRef, {
      [`children.${profileId}.settings`]: {
        ...family.children[profileId].settings,
        ...settings,
      },
      [`children.${profileId}.updatedAt`]: new Date(),
      updatedAt: serverTimestamp(),
    });
  }, [user, family]);

  const value: FamilyContextType = {
    family,
    currentProfileId,
    currentProfile,
    isParentMode,
    isLoading,
    needsSetup,
    profiles,
    selectProfile,
    enterParentMode,
    exitParentMode,
    createChildProfile,
    updateChildProfile,
    deleteChildProfile,
    setupParentPin,
    updateParentSettings,
    updateChildSettings,
    showProfileSwitcher,
    setShowProfileSwitcher,
  };

  return (
    <FamilyContext.Provider value={value}>
      {children}
    </FamilyContext.Provider>
  );
};

// Utility functions for profile creation
export const getRandomAvatar = (): string => {
  return CHILD_AVATARS[Math.floor(Math.random() * CHILD_AVATARS.length)];
};

export const getRandomThemeColor = (): string => {
  return CHILD_THEME_COLORS[Math.floor(Math.random() * CHILD_THEME_COLORS.length)];
};

export const getDefaultChildName = (index: number): string => {
  const defaults = ['Child 1', 'Child 2', 'Child 3', 'Child 4'];
  return defaults[index] || `Child ${index + 1}`;
};
