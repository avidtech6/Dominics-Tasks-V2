/**
 * Simple Dev Mode Service
 * Provides basic mock services for offline testing
 */

// Check if we're in dev mode
export const isDevMode = (): boolean => {
  if (typeof window === 'undefined') return false;
  return new URLSearchParams(window.location.search).get('dev') === 'true';
};

// Mock user data
export const devUser = {
  uid: 'dev-user-123',
  email: 'dev@localhost',
  displayName: 'Dev Tester',
  role: 'parent' as const,
  currentStreak: 5,
  totalEP: 1500,
  level: 12,
  photoURL: undefined,
  unlockedAchievements: ['first-login', 'task-complete', 'streak-3'],
};

// Mock tasks
export const devTasks = [
  {
    id: 'task-1',
    title: 'Math Homework',
    description: 'Complete pages 45-48 in workbook',
    section: 'morning',
    status: 'pending',
    priority: 'high',
    dueDate: new Date(),
    deadlineDate: new Date(Date.now() + 86400000),
    createdAt: new Date(),
    createdBy: 'dev@localhost',
    order: 0,
    xp: 50,
    completedAt: null,
    archivedAt: null,
    deletedAt: null,
    assignedTo: ['Dominic'],
    category: 'school',
    tags: ['math', 'homework'],
    taskType: 'basic' as const,
    pointsValue: 50,
  },
  {
    id: 'task-2',
    title: 'Practice Piano',
    description: 'Practice for 30 minutes',
    section: 'afternoon',
    status: 'pending',
    priority: 'medium',
    dueDate: new Date(),
    deadlineDate: new Date(Date.now() + 86400000 * 2),
    createdAt: new Date(),
    createdBy: 'dev@localhost',
    order: 1,
    xp: 30,
    completedAt: null,
    archivedAt: null,
    deletedAt: null,
    assignedTo: ['Dominic'],
    category: 'music',
    tags: ['piano', 'practice'],
    taskType: 'basic' as const,
    pointsValue: 30,
  },
];

// Mock storage upload with progress
export const mockUploadWithProgress = (
  _file: File,
  onProgress?: (progress: number) => void
): Promise<string> => {
  return new Promise((resolve) => {
    let progress = 0;
    
    // Simulate compression (5% -> 10%)
    setTimeout(() => {
      if (onProgress) onProgress(5);
    }, 100);
    
    setTimeout(() => {
      if (onProgress) onProgress(10);
    }, 300);
    
    // Simulate upload progress (10% -> 100%)
    const interval = setInterval(() => {
      progress += Math.random() * 8 + 2;
      
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        if (onProgress) onProgress(100);
        resolve('https://mock-storage.googleapis.com/dev-upload/test-image.webp');
      } else {
        if (onProgress) onProgress(progress);
      }
    }, 200);
  });
};

// Mock Firestore operations
export const mockFirestore = {
  collection: (_name: string) => ({
    add: async (data: any) => {
      console.log(`[MOCK] Added to collection:`, data);
      return { id: `mock-${Date.now()}` };
    },
    where: (_field: string, _op: string, _value: any) => ({
      get: async () => ({
        docs: devTasks.map(task => ({
          id: task.id,
          data: () => task,
        })),
      }),
    }),
    get: async () => ({
      docs: devTasks.map(task => ({
        id: task.id,
        data: () => task,
      })),
    }),
  }),
  doc: (path: string) => ({
    get: async () => ({
      exists: path.includes('dev-user'),
      data: () => devUser,
    }),
    set: async (data: any) => console.log(`[MOCK] Set ${path}:`, data),
    update: async (data: any) => console.log(`[MOCK] Update ${path}:`, data),
  }),
};
