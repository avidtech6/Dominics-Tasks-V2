/**
 * Firebase Services with Dev Mode Support
 * Lazy initialization to support dev mode bypass
 */

import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, setPersistence, browserLocalPersistence, browserSessionPersistence, AuthError } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { isDevMode, mockUploadWithProgress } from './devMode';
import { User, UserRole } from '../types';

// Firebase configuration from credentials
const firebaseConfig = {
  apiKey: "AIzaSyDqaJdLrUythnSYRK_kEiY7lduLCK2a9AI",
  authDomain: "dominics-tasks.firebaseapp.com",
  projectId: "dominics-tasks",
  storageBucket: "dominics-tasks.firebasestorage.app",
  messagingSenderId: "493020454735",
  appId: "1:493020454735:web:bc86b67dff201542cc2f3a"
};

// Lazy initialization
let app: any = null;
let auth: any = null;
let db: any = null;
let storage: any = null;
let googleProvider: any = null;

// Mock database for dev mode
const mockDb = {
  collection: (name: string) => ({
    add: async (data: any) => ({ id: `mock-${Date.now()}` }),
    doc: (id: string) => ({
      get: async () => ({ exists: false, data: () => undefined, id }),
      set: async () => {},
      update: async () => {},
    }),
    where: (field: string, op: string, value: any) => ({
      get: async () => ({ docs: [] }),
      onSnapshot: (callback: any) => {
        // Return empty snapshot immediately
        callback({ docs: [] });
        // Return unsubscribe function
        return () => {};
      },
    }),
    get: async () => ({ docs: [] }),
    onSnapshot: (callback: any) => {
      // Return empty snapshot immediately
      callback({ docs: [] });
      // Return unsubscribe function
      return () => {};
    },
  }),
};

function initializeFirebase() {
  if (app) return; // Already initialized
  
  if (isDevMode()) {
    console.log('🔧 DEV MODE: Skipping Firebase initialization');
    return;
  }
  
  try {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    storage = getStorage(app);
    googleProvider = new GoogleAuthProvider();

    // Set auth persistence to LOCAL - this is CRITICAL for redirect auth to work
    // browserLocalPersistence stores the auth token in localStorage
    // browserSessionPersistence only stores it for the current session
    setPersistence(auth, browserLocalPersistence).catch((error: AuthError) => {
      console.warn('Auth persistence setting failed:', error.message);
    });
  } catch (error) {
    console.error('Failed to initialize Firebase:', error);
  }
}

// Export functions that initialize on first use
export const getAuthService = () => {
  if (isDevMode()) {
    return null; // Return null so callers know to skip auth operations
  }
  initializeFirebase();
  return auth;
};

export const getGoogleProvider = () => {
  if (isDevMode()) {
    return null;
  }
  initializeFirebase();
  return googleProvider;
};

export const getDbService = () => {
  if (isDevMode()) {
    return mockDb;
  }
  initializeFirebase();
  // Ensure db is properly initialized before returning
  if (!db) {
    console.error('Firestore database not initialized!');
    throw new Error('Database not initialized. Please refresh the page.');
  }
  return db;
};

export const getStorageService = () => {
  if (isDevMode()) {
    return null;
  }
  initializeFirebase();
  return storage;
};

// For backwards compatibility, also export the initialized services
export const getFirebaseAuth = () => getAuthService();
export const getFirebaseDb = () => getDbService();
export const getFirebaseStorage = () => getStorageService();

// Authorize email lists
export const AUTHORIZED_EMAILS = [
  'dominicgiles691@gmail.com',
  'derrickmg.admin@gmail.com',
  'brendamgiles@gmail.com',
];

export const PARENT_EMAILS = [
  'derrickmg.admin@gmail.com',
  'brendamgiles@gmail.com',
];

// Helper to check if error is storage-related
export const isStorageError = (error: any): boolean => {
  return error?.message?.includes('storage') ||
         error?.code === 'storage/unauthorized' ||
         error?.code === 'storage/canceled';
};

// Upload image helper
export const uploadImage = async (file: File, path: string): Promise<string> => {
  const storageRef = ref(getStorageService(), path);
  const snapshot = await uploadBytes(storageRef, file);
  return getDownloadURL(snapshot.ref);
};

// Better compression with intelligent sizing
const compressImage = (file: File): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      
      // Smart sizing - phone photos are typically 3000-4000px, we don't need that for chat
      // 800px is plenty for clear display on phones and tablets
      const maxSize = 800;
      let width = img.width;
      let height = img.height;
      
      // Scale down if too large
      if (width > maxSize || height > maxSize) {
        if (width > height) {
          height = Math.round((height * maxSize) / width);
          width = maxSize;
        } else {
          width = Math.round((width * maxSize) / height);
          height = maxSize;
        }
      }
      
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      
      // Use higher quality (70%) but WebP for better compression
      // WebP typically gives 25-34% smaller files than JPEG at same quality
      canvas.toBlob(
        (blob) => {
          if (blob) {
            const originalSizeKB = file.size / 1024;
            const compressedSizeKB = blob.size / 1024;
            const reduction = ((originalSizeKB - compressedSizeKB) / originalSizeKB * 100).toFixed(0);
            console.log(`Compressed: ${originalSizeKB.toFixed(1)}KB → ${compressedSizeKB.toFixed(1)}KB (${reduction}% smaller)`);
            resolve(blob);
          } else {
            reject(new Error('Compression failed - could not convert image'));
          }
        },
        'image/webp', // WebP - better compression than JPEG
        0.7 // 70% quality - good balance of quality vs size
      );
    };
    img.onerror = () => reject(new Error('Failed to load image for compression - file may be corrupted or format not supported'));
    img.src = URL.createObjectURL(file);
  });
};

// Upload chat attachment with AbortController support for proper cancellation
export const uploadChatAttachment = async (
  file: File, 
  chatId: string, 
  messageId: string,
  onProgress?: (progress: number) => void
): Promise<{ url: string; thumbnailUrl?: string; fileType: string }> => {
  const timestamp = Date.now();
  const fileExtension = file.name.split('.').pop() || 'bin';
  const fileType = file.type.startsWith('image/') ? 'image' : 
                   file.type.startsWith('video/') ? 'video' : 
                   file.type.startsWith('audio/') ? 'audio' : 'document';
  
  const path = `chat-attachments/${chatId}/${messageId}/${timestamp}.${fileExtension}`;
  console.log('Processing file:', file.name, 'Original size:', (file.size/1024).toFixed(1), 'KB');
  
  // Check for dev mode - use mock upload
  if (isDevMode()) {
    console.log('🔧 DEV MODE: Using mock upload with progress');

    // Compress image first (in memory)
    if (file.type.startsWith('image/')) {
      if (onProgress) onProgress(5);
      try {
        // Use timeout to prevent hanging
        const compressionPromise = compressImage(file);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Compression timeout')), 2000)
        );

        await Promise.race([compressionPromise, timeoutPromise]);
        if (onProgress) onProgress(10);
      } catch (error) {
        console.warn('🔧 DEV MODE: Compression failed or timed out, continuing with mock upload');
        if (onProgress) onProgress(10);
      }
    } else {
      if (onProgress) onProgress(10);
    }

    // Use mock upload with progress - starts from current progress (10%)
    const mockUrl = await mockUploadWithProgress(file, onProgress);

    return {
      url: mockUrl,
      fileType,
    };
  }
  
  // Create abort controller for proper cancellation
  const abortController = new AbortController();
  
  try {
    let fileToUpload = file;
    let finalSizeKB = file.size / 1024;
    
    // Compress all images aggressively
    if (file.type.startsWith('image/')) {
      console.log('Compressing image...');
      // Report compression start - images need processing time
      if (onProgress) onProgress(5);

      try {
        // Use timeout to prevent hanging on compression
        const compressionPromise = compressImage(file);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Compression timeout')), 5000)
        );

        const compressedBlob = await Promise.race([compressionPromise, timeoutPromise]);
        // Report compression complete, upload starting
        if (onProgress) onProgress(10);
        fileToUpload = new File([compressedBlob], file.name, { type: 'image/jpeg' });
        finalSizeKB = compressedBlob.size / 1024;
        console.log('Compression successful:', finalSizeKB.toFixed(1), 'KB');
        // Use compressedBlob to avoid unused variable warning
        void compressedBlob.size;
      } catch (compressError: any) {
        console.warn('Compression failed or timed out, uploading original:', compressError.message);
        // Report compression failed/timed out, continuing with original
        if (onProgress) onProgress(10);
      }
    } else {
      // Non-image files - report 10% to show we've processed them
      if (onProgress) onProgress(10);
    }
    
    const storageRef = ref(getStorageService(), path);
    
    // Start upload and track it
    let uploadTask;
    
    try {
      uploadTask = uploadBytesResumable(storageRef, fileToUpload);
    } catch (uploadStartError: any) {
      console.error('Failed to start upload:', uploadStartError);
      throw new Error('Failed to start upload: ' + uploadStartError.message);
    }
    
    // Set up timeout with AbortController support
    const timeoutMs = 90000; // 90 seconds for mobile
    const timeoutId = setTimeout(() => {
      abortController.abort();
      console.log('Upload timeout triggered after', timeoutMs, 'ms');
    }, timeoutMs);
    
    // Set up progress monitoring - map 0-100% upload to 10-100% overall
    if (onProgress && typeof onProgress === 'function') {
      uploadTask.on('state_changed', 
        (snapshot) => {
          // Handle different upload states
          const state = snapshot.state;
          
          // If upload is running or paused, calculate progress
          if (state === 'running' || state === 'paused') {
            // Map upload progress (0-100) to overall progress (10-100)
            const uploadProgress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            const overallProgress = 10 + (uploadProgress * 0.9); // Scale to 10-100 range
            console.log(`Upload progress: ${uploadProgress.toFixed(1)}%, Overall: ${overallProgress.toFixed(1)}%`);
            onProgress(Math.round(overallProgress));
          }
          
          // If upload succeeded, ensure 100% completion
          if (state === 'success') {
            console.log('Upload completed successfully');
            onProgress(100);
          }
        },
        (error) => {
          console.error('Upload progress error:', error);
        }
      );
    }
    
    // Race between upload completion and timeout
    let snapshot;
    let uploadSucceeded = false;
    
    try {
      snapshot = await Promise.race([
        uploadTask.then(result => {
          uploadSucceeded = true;
          clearTimeout(timeoutId);
          // Ensure progress shows 100% on completion
          if (onProgress && typeof onProgress === 'function') {
            onProgress(100);
          }
          return result;
        }),
        new Promise<never>((_, reject) => {
          abortController.signal.addEventListener('abort', () => {
            // Try to cancel the upload task
            try {
              uploadTask.cancel();
            } catch (e) {
              console.warn('Could not cancel upload task');
            }
            reject(new Error('Upload timed out. The file may be too large for the current network. Try a smaller image.'));
          });
        })
      ]);
    } catch (raceError: any) {
      // Clear progress on error - show 0% to indicate failure
      if (onProgress && typeof onProgress === 'function') {
        onProgress(0);
      }
      // Try to cancel the upload
      try {
        uploadTask.cancel();
      } catch (e) {
        // Ignore cancellation errors
      }
      throw raceError;
    }
    
    // Final safety check - ensure progress is 100% before returning
    if (onProgress && typeof onProgress === 'function') {
      onProgress(100);
    }
    
    // Get the download URL
    let downloadUrl: string;
    try {
      downloadUrl = await getDownloadURL(snapshot.ref);
    } catch (urlError) {
      console.error('Failed to get download URL:', urlError);
      // Return a constructed URL as fallback
      downloadUrl = `https://firebasestorage.googleapis.com/v0/b/${firebaseConfig.projectId}.appspot.com/o/${encodeURIComponent(path)}?alt=media`;
    }
    
    console.log('Upload complete:', (finalSizeKB).toFixed(1), 'KB');
    
    return {
      url: downloadUrl,
      fileType,
    };
  } catch (error: any) {
    if (error.message.includes('timed out') || error.message.includes('aborted')) {
      throw error;
    }
    console.error('Upload failed:', error);
    throw new Error('Upload failed. Please check your connection and try again.');
  }
};

// Export services for use in other modules
export { app, auth, db, storage, googleProvider };
export { isDevMode, devUser } from './devMode';
