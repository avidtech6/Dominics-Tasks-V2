/**
 * Google Drive Integration Service
 * Provides file picker functionality for selecting files from Google Drive
 */

// Google Drive API configuration
const GOOGLE_CLIENT_ID = '493020454735.apps.googleusercontent.com';
const GOOGLE_API_KEY = 'AIzaSyDqaJdLrUythnSYRK_kEiY7lduLCK2a9AI';
const DISCOVERY_DOCS = ['https://www.googleapis.com/discovery/v1/apis/drive/v3/rest'];
const SCOPES = 'https://www.googleapis.com/auth/drive.file';

let gapiLoaded = false;
let gisLoaded = false;
let tokenClient: google.accounts.oauth2.TokenClient | null = null;

// Types for Google API
declare global {
  interface Window {
    gapi: any;
    google: any;
  }
}

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  webViewLink: string;
  iconLink: string;
  size?: number;
}

// Load the Google APIs
export const loadGoogleApis = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Load GAPI (for Drive API)
    if (!window.gapi) {
      const gapiScript = document.createElement('script');
      gapiScript.src = 'https://apis.google.com/js/api.js';
      gapiScript.async = true;
      gapiScript.defer = true;
      gapiScript.onload = () => {
        window.gapi.load('client', async () => {
          try {
            await window.gapi.client.init({
              apiKey: GOOGLE_API_KEY,
              discoveryDocs: DISCOVERY_DOCS,
            });
            gapiLoaded = true;
            checkAllLoaded();
          } catch (error) {
            console.error('[GoogleDrive] GAPI init failed:', error);
          }
        });
      };
      gapiScript.onerror = () => reject(new Error('Failed to load GAPI'));
      document.body.appendChild(gapiScript);
    } else {
      gapiLoaded = true;
      checkAllLoaded();
    }

    // Load GIS (for OAuth)
    if (!window.google?.accounts) {
      const gisScript = document.createElement('script');
      gisScript.src = 'https://accounts.google.com/gsi/client';
      gisScript.async = true;
      gisScript.defer = true;
      gisScript.onload = () => {
        try {
          tokenClient = window.google.accounts.oauth2.initTokenClient({
            client_id: GOOGLE_CLIENT_ID,
            scope: SCOPES,
            callback: () => {}, // Will be overridden per request
          });
          gisLoaded = true;
          checkAllLoaded();
        } catch (error) {
          console.error('[GoogleDrive] GIS init failed:', error);
        }
      };
      gisScript.onerror = () => reject(new Error('Failed to load GIS'));
      document.body.appendChild(gisScript);
    } else {
      gisLoaded = true;
      checkAllLoaded();
    }

    function checkAllLoaded() {
      if (gapiLoaded && gisLoaded) {
        resolve();
      }
    }
  });
};

// Check if APIs are ready
export const isGoogleReady = (): boolean => {
  return gapiLoaded && gisLoaded && !!tokenClient;
};

// Request access to Google Drive
export const requestDriveAccess = (): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!tokenClient) {
      reject(new Error('Google Identity Services not loaded'));
      return;
    }

    tokenClient.callback = (response: any) => {
      if (response.error) {
        reject(new Error(response.error));
      } else {
        resolve(response.access_token);
      }
    };

    // Request access token with interactive consent
    try {
      tokenClient.requestAccessToken({ prompt: 'consent' });
    } catch (error) {
      // If prompt fails, try without consent (for re-auth)
      try {
        tokenClient.requestAccessToken({ prompt: '' });
      } catch (retryError: any) {
        reject(new Error(retryError.message || 'Failed to get Drive access'));
      }
    }
  });
};

// Get file details from Drive
export const getDriveFileDetails = async (fileId: string, accessToken: string): Promise<DriveFile> => {
  const response = await window.gapi.client.drive.files.get({
    fileId: fileId,
    fields: 'id, name, mimeType, webViewLink, iconLink, size',
    alt: 'json',
  });

  return {
    id: response.result.id,
    name: response.result.name,
    mimeType: response.result.mimeType,
    webViewLink: response.result.webViewLink,
    iconLink: response.result.iconLink,
    size: response.result.size ? parseInt(response.result.size) : undefined,
  };
};

// List files from Google Drive
export const listDriveFiles = async (accessToken: string, folderId?: string): Promise<DriveFile[]> => {
  let query = "trashed = false and mimeType != 'application/vnd.google-apps.folder'";
  if (folderId) {
    query += ` and '${folderId}' in parents`;
  }

  const response = await window.gapi.client.drive.files.list({
    pageSize: 50,
    fields: 'files(id, name, mimeType, webViewLink, iconLink, size)',
    q: query,
    orderBy: 'modifiedTime desc',
  });

  return response.result.files.map((file: any) => ({
    id: file.id,
    name: file.name,
    mimeType: file.mimeType,
    webViewLink: file.webViewLink,
    iconLink: file.iconLink,
    size: file.size ? parseInt(file.size) : undefined,
  }));
};

// Get file content as a blob (for uploading to Firebase)
export const getDriveFileContent = async (fileId: string, accessToken: string): Promise<Blob> => {
  const response = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error('Failed to download file from Google Drive');
  }

  return response.blob();
};

// Check if a file is a Google Doc/Sheet/Slides that needs export
export const isGoogleWorkspaceFile = (mimeType: string): boolean => {
  return mimeType.startsWith('application/vnd.google-apps.');
};

// Export Google Workspace file as PDF or other format
export const exportWorkspaceFile = async (
  fileId: string, 
  mimeType: string, 
  accessToken: string
): Promise<Blob> => {
  let exportMimeType = 'application/pdf';
  
  // Map Google types to export formats
  if (mimeType === 'application/vnd.google-apps.document') {
    exportMimeType = 'application/pdf';
  } else if (mimeType === 'application/vnd.google-apps.spreadsheet') {
    exportMimeType = 'application/pdf';
  } else if (mimeType === 'application/vnd.google-apps.presentation') {
    exportMimeType = 'application/pdf';
  }

  const response = await fetch(
    `https://www.googleapis.com/drive/v3/files/${fileId}/export?mimeType=${exportMimeType}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error('Failed to export file from Google Drive');
  }

  return response.blob();
};

// Simple file picker using Drive URL input (fallback for when Picker API is not configured)
export const parseDriveUrl = (url: string): { fileId: string; valid: boolean } => {
  // Match various Google Drive URL formats
  const patterns = [
    /\/d\/([a-zA-Z0-9_-]+)\//,           // /d/FILE_ID/
    /\/d\/([a-zA-Z0-9_-]+)$/,             // /d/FILE_ID (end of string)
    /id=([a-zA-Z0-9_-]+)/,                // id=FILE_ID
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      return { fileId: match[1], valid: true };
    }
  }

  return { fileId: '', valid: false };
};

// Create a human-readable file size string
export const formatFileSize = (bytes?: number): string => {
  if (!bytes) return 'Unknown size';
  
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
};

// Get file type icon based on MIME type
export const getFileTypeIcon = (mimeType: string): string => {
  if (mimeType.startsWith('image/')) return '🖼️';
  if (mimeType.startsWith('video/')) return '🎬';
  if (mimeType.startsWith('audio/')) return '🎵';
  if (mimeType.includes('pdf')) return '📄';
  if (mimeType.includes('document') || mimeType.includes('word')) return '📝';
  if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return '📊';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return '📽️';
  if (mimeType.includes('zip') || mimeType.includes('compressed')) return '📦';
  return '📎';
};

// Detect file type from MIME type
export const getFileCategory = (mimeType: string): 'image' | 'video' | 'audio' | 'document' => {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  return 'document';
};
