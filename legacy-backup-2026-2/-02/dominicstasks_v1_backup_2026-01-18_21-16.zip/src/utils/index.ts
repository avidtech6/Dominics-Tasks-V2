import { format, formatDistanceToNow, differenceInDays, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isYesterday } from 'date-fns';
import { Task, TaskType, TaskPriority, TaskSection, TaskStatus } from '../types';
import { TASK_TYPES, PRIORITY_LEVELS } from '../types';

// Date formatting utilities
export const formatDate = (date: Date | null | undefined): string => {
  if (!date) return '';
  return format(date, 'MMM d, yyyy');
};

export const formatTime = (date: Date | null | undefined): string => {
  if (!date) return '';
  return format(date, 'h:mm a');
};

export const formatDateTime = (date: Date | null | undefined): string => {
  if (!date) return '';
  return format(date, 'MMM d, yyyy h:mm a');
};

export const formatRelativeTime = (date: Date | null | undefined): string => {
  if (!date) return '';
  return formatDistanceToNow(date, { addSuffix: true });
};

export const getDaysUntilDeadline = (deadlineDate: Date | null | undefined): number | null => {
  if (!deadlineDate) return null;
  return differenceInDays(deadlineDate, new Date());
};

// NEW: Today-specific date utilities
export const isTodayDate = (date: Date | null | undefined): boolean => {
  if (!date) return false;
  return isToday(date);
};

export const isYesterdayDate = (date: Date | null | undefined): boolean => {
  if (!date) return false;
  return isYesterday(date);
};

export const isOverdue = (date: Date | null | undefined): boolean => {
  if (!date) return false;
  return date < new Date() && !isToday(date);
};

// NEW: Check if task should appear in today's focus (morning/afternoon)
export const shouldShowInTodayFocus = (task: Task): boolean => {
  // Already in today status and not done
  if (task.status === 'today') return true;
  
  // Has a dueDate set to today
  if (isTodayDate(task.dueDate) && task.status !== 'done') return true;
  
  // Has a deadlineDate set to today
  if (isTodayDate(task.deadlineDate) && task.status !== 'done') return true;
  
  return false;
};

// NEW: Check if task is overdue and needs to be caught up
export const needsCatchUp = (task: Task): boolean => {
  if (task.status === 'done') return false;
  
  // Overdue due date (yesterday or earlier)
  // isOverdue already includes yesterday in its check
  if (task.dueDate && isOverdue(task.dueDate)) return true;
  
  // Overdue deadline date (yesterday or earlier)
  if (task.deadlineDate && isOverdue(task.deadlineDate)) return true;
  
  return false;
};

// NEW: Check if task is from yesterday and not done
export const isFromYesterday = (task: Task): boolean => {
  if (task.status === 'done') return false;
  
  if (task.dueDate && isYesterdayDate(task.dueDate)) return true;
  if (task.deadlineDate && isYesterdayDate(task.deadlineDate)) return true;
  
  return false;
};

// NEW: Get tasks that should be mirrored in Today's Focus from right column
export const getMirroredTasksForToday = (tasks: Task[]): Task[] => {
  return tasks.filter(task => 
    task.status !== 'done' && 
    !task.deletedAt &&
    !task.archivedAt &&
    (isTodayDate(task.dueDate) || isTodayDate(task.deadlineDate))
  );
};

// NEW: Format date for display - shows "Today", "Yesterday", or actual date
export const formatSmartDate = (date: Date | null | undefined): string => {
  if (!date) return '';
  
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  
  return format(date, 'MMM d, yyyy');
};

// Calendar utilities
export const getMonthDays = (year: number, month: number): Date[] => {
  const start = startOfMonth(new Date(year, month));
  const end = endOfMonth(new Date(year, month));
  return eachDayOfInterval({ start, end });
};

export const getCalendarDays = (year: number, month: number): (Date | null)[] => {
  const days = getMonthDays(year, month);
  const firstDayOfWeek = startOfMonth(new Date(year, month)).getDay();

  const calendarDays: (Date | null)[] = [];

  // Add empty days for padding
  for (let i = 0; i < firstDayOfWeek; i++) {
    calendarDays.push(null);
  }

  // Add actual days
  days.forEach((day) => calendarDays.push(day));

  return calendarDays;
};

// EP and Level utilities
export const calculateLevel = (totalEP: number): number => {
  return Math.floor(totalEP / 1000) + 1;
};

export const getEPForNextLevel = (totalEP: number): number => {
  return Math.ceil(totalEP / 1000) * 1000;
};

export const getEPProgress = (totalEP: number): number => {
  const currentLevelEP = Math.floor(totalEP / 1000) * 1000;
  return ((totalEP - currentLevelEP) / 1000) * 100;
};

// Streak utilities
export const getStreakEmoji = (streak: number): string => {
  if (streak >= 30) return '🔥';
  if (streak >= 14) return '⚡';
  if (streak >= 7) return '💪';
  if (streak >= 3) return '🌟';
  return '📈';
};

// Task type utilities
export const getTaskTypeConfig = (taskType: TaskType) => {
  return TASK_TYPES[taskType];
};

export const getPriorityConfig = (priority: TaskPriority) => {
  return PRIORITY_LEVELS[priority];
};

export const getTaskTypeIcon = (taskType: TaskType): string => {
  return TASK_TYPES[taskType]?.icon || '📋';
};

export const getTaskTypeColor = (taskType: TaskType): string => {
  return TASK_TYPES[taskType]?.color || '#3B82F6';
};

// Deadline status
export const getDeadlineStatus = (
  deadlineDate: Date | null | undefined,
  status: TaskStatus
): 'overdue' | 'urgent' | 'upcoming' | 'none' => {
  if (status === 'done') return 'none';
  if (!deadlineDate) return 'none';

  const daysUntil = getDaysUntilDeadline(deadlineDate) || 0;

  if (daysUntil < 0) return 'overdue';
  if (daysUntil <= 1) return 'urgent';
  if (daysUntil <= 7) return 'upcoming';

  return 'none';
};

export const getDeadlineStatusColor = (status: string): string => {
  switch (status) {
    case 'overdue':
      return 'text-red-600 bg-red-100';
    case 'urgent':
      return 'text-orange-600 bg-orange-100';
    case 'upcoming':
      return 'text-blue-600 bg-blue-100';
    default:
      return 'text-gray-600 bg-gray-100';
  }
};

// Section display names
export const getSectionDisplayName = (section: TaskSection): string => {
  const sectionNames: Record<TaskSection, string> = {
    morning: 'Morning',
    afternoon: 'Afternoon',
    assignments: 'Assignments Due',
    leftovers: 'Left Over',
    experiments: 'Experiments',
    support: 'Support & Activities',
    catchup: 'Catch Up',
  };
  return sectionNames[section] || section;
};

// Status display names
export const getStatusDisplayName = (status: TaskStatus): string => {
  const statusNames: Record<TaskStatus, string> = {
    todo: 'To Do',
    today: 'Today',
    done: 'Done',
  };
  return statusNames[status] || status;
};

// Fun comment templates
export const FUN_COMMENTS = {
  encouragement: [
    "You've got this! 🌟",
    "Ready to shine? ✨",
    "Champ in the making! 🏆",
    "Believe in yourself! 💪",
    "You're going to crush this! 🎯",
  ],
  motivational: [
    "Time to crush this! 💪",
    "Let's do this! 🚀",
    "Your moment to shine! ⚡",
    "No excuses, just results! 🔥",
    "Be the best version of yourself! 🌈",
  ],
  humorous: [
    "The clock is ticking... 🕰️",
    "This won't complete itself... 👀",
    "Your future self is watching! 👀",
    "Procrastination called, you didn't answer! 📞",
    "Nap time is over! 😴",
  ],
  celebration: [
    "AMAZING job! 🎉",
    "You did it! 🌟",
    "Superstar performance! ⭐",
    "Incredible work! 🏅",
    "You're on fire! 🔥",
  ],
  silly: [
    "Do a little dance! 💃",
    "High five from the task! ✋",
    "Your brain is about to get smarter! 🧠",
    "Spa day after this! 🧖",
    "Snack break when you're done! 🍎",
  ],
};

// Random fun comment picker
export const getRandomFunComment = (type: keyof typeof FUN_COMMENTS): string => {
  const comments = FUN_COMMENTS[type];
  return comments[Math.floor(Math.random() * comments.length)];
};

// Achievement definitions
export const ACHIEVEMENTS = [
  {
    id: 'first_step',
    title: 'First Step',
    description: 'Complete your first task',
    icon: '🌟',
    epReward: 50,
    category: 'daily' as const,
    check: (tasks: Task[]) => tasks.some((t) => t.status === 'done'),
  },
  {
    id: 'week_warrior',
    title: 'Week Warrior',
    description: 'Maintain a 7-day streak',
    icon: '💪',
    xpReward: 200,
    category: 'daily' as const,
    check: (_tasks: Task[], streak: number) => streak >= 7,
  },
  {
    id: 'month_master',
    title: 'Month Master',
    description: 'Maintain a 30-day streak',
    icon: '👑',
    xpReward: 500,
    category: 'daily' as const,
    check: (_tasks: Task[], streak: number) => streak >= 30,
  },
  {
    id: 'century_club',
    title: 'Century Club',
    description: 'Complete 100 tasks',
    icon: '💯',
    xpReward: 500,
    category: 'special' as const,
    check: (tasks: Task[]) => tasks.filter((t) => t.status === 'done').length >= 100,
  },
];

// String utilities
export const capitalize = (str: string): string => {
  return str.charAt(0).toUpperCase() + str.slice(1);
};

export const truncate = (str: string, maxLength: number): string => {
  if (str.length <= maxLength) return str;
  return str.slice(0, maxLength) + '...';
};

// Array utilities
export const groupBy = <T>(array: T[], key: keyof T): Record<string, T[]> => {
  return array.reduce((result, item) => {
    const groupKey = String(item[key]);
    if (!result[groupKey]) {
      result[groupKey] = [];
    }
    result[groupKey].push(item);
    return result;
  }, {} as Record<string, T[]>);
};

export const sortByDate = <T extends { dueDate?: Date | null }>(
  array: T[],
  ascending = true
): T[] => {
  return [...array].sort((a, b) => {
    const dateA = a.dueDate?.getTime() || 0;
    const dateB = b.dueDate?.getTime() || 0;
    return ascending ? dateA - dateB : dateB - dateA;
  });
};
