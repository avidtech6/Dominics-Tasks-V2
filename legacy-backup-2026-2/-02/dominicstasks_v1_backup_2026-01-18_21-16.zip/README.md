# Dominic's Tasks - Family Task Management Application

A comprehensive family task management application built with React, TypeScript, and Firebase. The app helps families coordinate tasks, track progress, communicate through private and group chats, and celebrate achievements together.

## Features

### Core Functionality
- **Task Management**: Create, assign, and track tasks with a drag-and-drop Kanban board
- **Progress Tracking**: Visual progress indicators and completion statistics
- **Calendar View**: View tasks scheduled across different dates
- **Points System**: Earn points for completed tasks with automatic calculation
- **Achievement System**: Unlock badges and celebrate milestones
- **Family Chat**: Group messaging for the entire family
- **Parent Chat**: Private messaging channel hidden from children
- **File Attachments**: Share images and documents in chats
- **Emoji Reactions**: React to messages with quick emoji responses
- **Comments System**: Add fun comments and feedback to completed tasks
- **Resource Library**: Curated learning resources and links

### User Roles
- **Parents**: Full access to all features including Parent Chat and analytics
- **Children**: Access to tasks, family chat, achievements, and resources

## Tech Stack

- **Frontend**: React 18 with TypeScript
- **Build Tool**: Vite 5
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM 6
- **State Management**: React Context API
- **Drag & Drop**: @dnd-kit/core
- **Backend**: Firebase (Firestore, Storage, Authentication)
- **Charts**: Recharts
- **Animations**: Framer Motion
- **Date Handling**: date-fns
- **Icons**: Lucide React
- **Deployment**: Cloudflare Pages

## Project Structure

```
dominicstasks/
├── src/
│   ├── components/
│   │   ├── AchievementBadge.tsx    # Achievement badge component
│   │   ├── CommentsPanel.tsx       # Fun comments panel for tasks
│   │   ├── ConfettiCelebration.tsx # Celebration animation
│   │   ├── Layout.tsx              # Main app layout
│   │   ├── TaskCard.tsx            # Individual task card
│   │   ├── TaskColumn.tsx          # Task column (Todo/In Progress/Done)
│   │   └── TaskModal.tsx           # Task creation/editing modal
│   ├── context/
│   │   ├── AuthContext.tsx         # Authentication state management
│   │   └── TasksContext.tsx        # Tasks and points state management
│   ├── pages/
│   │   ├── Achievements.tsx        # Achievements gallery
│   │   ├── Calendar.tsx            # Calendar view of tasks
│   │   ├── FamilyChat.tsx          # Family group chat
│   │   ├── History.tsx             # Task completion history
│   │   ├── Login.tsx               # Login page
│   │   ├── ParentChat.tsx          # Private parent chat
│   │   ├── Resources.tsx           # Learning resources
│   │   └── Tasks.tsx               # Main tasks Kanban board
│   ├── services/
│   │   ├── devMode.ts              # Development mode utilities
│   │   └── firebase.ts             # Firebase configuration
│   ├── types/
│   │   └── index.ts                # TypeScript type definitions
│   ├── utils/
│   │   └── index.ts                # Utility functions
│   ├── App.tsx                     # Main app component
│   ├── main.tsx                    # App entry point
│   └── index.css                   # Global styles
├── public/
│   └── _headers                    # Cloudflare Pages headers
├── dist/                           # Production build output
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
└── wrangler.toml                   # Cloudflare configuration
```

## Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- Firebase project with Firestore, Storage, and Authentication enabled

### Installation

1. Clone the repository:
```bash
cd dominicstasks
```

2. Install dependencies:
```bash
npm install
```

3. Configure Firebase:
   - Copy `src/services/firebase.example.ts` to `src/services/firebase.ts`
   - Add your Firebase configuration credentials

4. Start development server:
```bash
npm run dev
```

5. Build for production:
```bash
npm run build
```

### Environment Variables

Create a `.env` file in the root directory:

```env
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

## Deployment

### Cloudflare Pages

The project is configured for deployment to Cloudflare Pages using Wrangler CLI.

1. Build the project:
```bash
npm run build
```

2. Deploy using Wrangler:
```bash
npx wrangler pages deploy dist --project-name=dominicstasks
```

Or use the deployment script:
```bash
node deploy-api.cjs
```

### Automatic Caching

Cloudflare Pages automatically caches static assets. To force cache invalidation, add a cache-busting query parameter to asset URLs or redeploy the application.

## Firebase Security Rules

### Firestore Rules
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Private messages - only authenticated users
    match /private_messages/{messageId} {
      allow read, write: if request.auth != null;
    }
    
    // Tasks - all authenticated users
    match /tasks/{taskId} {
      allow read, write: if request.auth != null;
    }
    
    // Achievements - all authenticated users
    match /achievements/{achievementId} {
      allow read, write: if request.auth != null;
    }
    
    // User points - only the user or parents
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### Storage Rules
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Chat attachments - only authenticated users
    match /chat_attachments/{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

## Features Overview

### Task Points System
Tasks can be assigned point values:
- Small tasks: 1-5 points
- Medium tasks: 6-15 points
- Large tasks: 16-30 points

Points are automatically calculated and tracked in the user's profile.

### Achievement Categories
- **Daily Goals**: Complete daily tasks consistently
- **Weekly Milestones**: Reach weekly point targets
- **Streak**: Maintain consistent task completion
- **Mastery**: Complete challenging tasks
- **Helper**: Assist other family members

### Chat Features
- Real-time messaging with Firestore
- File attachments (images, videos, documents)
- Emoji reactions
- Message editing and deletion
- Date separators and timestamps
- Private parent-only channel

## Development

### Running Tests
```bash
npm run test
```

### Linting
```bash
npm run lint
```

### Type Checking
```bash
npm run type-check
```

## Version History

### v1.0.0 (Current)
- Initial production release
- Complete task management system
- Family and Parent chat functionality
- Achievement and gamification features
- Resource library
- Deployment to Cloudflare Pages

## License

Private project - All rights reserved.

## Support

For questions or issues, please contact the development team.
